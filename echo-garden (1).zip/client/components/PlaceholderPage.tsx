import { useNavigate } from "react-router-dom";
import { ArrowLeft, Sparkles } from "lucide-react";

interface PlaceholderPageProps {
  title: string;
  description: string;
  icon?: React.ReactNode;
  ctaText?: string;
  onCTA?: () => void;
}

export function PlaceholderPage({
  title,
  description,
  icon,
  ctaText,
  onCTA,
}: PlaceholderPageProps) {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-card border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-2 text-primary font-semibold hover:gap-3 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
            Back
          </button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-lg font-bold text-white">P</span>
            </div>
            <h1 className="text-2xl font-bold text-foreground hidden sm:block">
              ParkEase
            </h1>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center">
          <div className="mb-8 flex justify-center">
            <div className="w-20 h-20 bg-gradient-to-br from-primary/10 to-secondary/10 rounded-2xl flex items-center justify-center">
              {icon || (
                <Sparkles className="w-10 h-10 text-primary" />
              )}
            </div>
          </div>

          <h1 className="text-4xl font-bold text-foreground mb-4">{title}</h1>

          <p className="text-xl text-muted-foreground mb-12 max-w-2xl mx-auto">
            {description}
          </p>

          <div className="bg-card border-2 border-dashed border-border rounded-2xl p-12 mb-8">
            <div className="flex items-center justify-center mb-4">
              <span className="text-6xl">🚀</span>
            </div>
            <p className="text-muted-foreground text-lg">
              This page is currently being built out. Continue prompting to fill in this page contents if you want it!
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => navigate("/")}
              className="px-6 py-3 rounded-lg border-2 border-primary text-primary font-semibold hover:bg-blue-50 transition-all"
            >
              Back to Home
            </button>
            {ctaText && onCTA && (
              <button
                onClick={onCTA}
                className="px-6 py-3 rounded-lg bg-primary text-white font-semibold hover:shadow-lg transition-all"
              >
                {ctaText}
              </button>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
