import { useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import {
  ArrowLeft,
  MapPin,
  Clock,
  DollarSign,
  Zap,
  Shield,
  AlertCircle,
  CheckCircle,
} from "lucide-react";

export default function Reservation() {
  const navigate = useNavigate();
  const [selectedSlot] = useState({
    id: "SL001",
    name: "Downtown Plaza - Level 2",
    location: "Connaught Place, Delhi",
    price: 50,
    availability: 12,
    distance: "450m",
    rating: 4.5,
    evCharging: true,
  });

  const [reservationData, setReservationData] = useState({
    date: "2024-01-20",
    startTime: "14:00",
    endTime: "16:00",
    duration: 2,
    includeEVCharging: false,
    vehicleNumber: "DL01AB1234",
  });

  const [timeRemaining, setTimeRemaining] = useState(600); // 10 minutes in seconds
  const [hasConfirmed, setHasConfirmed] = useState(false);

  // Countdown timer
  useEffect(() => {
    if (timeRemaining <= 0) return;

    const timer = setInterval(() => {
      setTimeRemaining((prev) => prev - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [timeRemaining]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const baseCost = selectedSlot.price * reservationData.duration;
  const evChargingCost = reservationData.includeEVCharging ? 80 : 0;
  const totalCost = baseCost + evChargingCost;
  const estimatedEcoPoints = Math.floor(totalCost * 0.5);

  const handleDurationChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newDuration = parseFloat(e.target.value);
    setReservationData((prev) => ({
      ...prev,
      duration: newDuration,
    }));
  };

  const handleConfirmReservation = () => {
    setHasConfirmed(true);
    // Navigate to payment after 2 seconds
    setTimeout(() => navigate("/payment"), 2000);
  };

  if (hasConfirmed) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="text-center">
          <div className="mb-8 flex justify-center">
            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-green-400 to-green-600 flex items-center justify-center animate-pulse">
              <CheckCircle className="w-12 h-12 text-white" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-foreground mb-4">
            Reservation Confirmed!
          </h1>
          <p className="text-muted-foreground text-lg mb-8">
            Proceeding to payment...
          </p>
          <div className="inline-block w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-card border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <button
            onClick={() => navigate("/prediction")}
            className="flex items-center gap-2 text-primary font-semibold hover:gap-3 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
            Back
          </button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-lg font-bold text-white">P</span>
            </div>
            <h1 className="text-2xl font-bold text-foreground hidden sm:block">
              ParkEase
            </h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Timer Warning */}
        <div className="mb-8 p-4 rounded-lg bg-yellow-50 border-2 border-yellow-200 flex items-center gap-3">
          <AlertCircle className="w-5 h-5 text-yellow-700 flex-shrink-0" />
          <div>
            <p className="font-semibold text-yellow-900">
              Slot reserved for {formatTime(timeRemaining)}
            </p>
            <p className="text-sm text-yellow-800">
              Complete your reservation before the timer expires
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Reservation Details */}
          <div className="lg:col-span-2 space-y-8">
            {/* Slot Confirmation */}
            <div className="p-8 rounded-2xl bg-card border-2 border-border">
              <h2 className="text-2xl font-bold text-foreground mb-6">
                Slot Confirmation
              </h2>

              <div className="p-6 rounded-xl bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-primary mb-6">
                <div className="flex items-start gap-4 mb-4">
                  <MapPin className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                  <div className="flex-1">
                    <h3 className="font-bold text-foreground text-lg">
                      {selectedSlot.name}
                    </h3>
                    <p className="text-muted-foreground">{selectedSlot.location}</p>
                  </div>
                  <span className="px-3 py-1 rounded-full bg-green-100 text-secondary font-semibold text-sm">
                    Available
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground mb-1">Distance</p>
                    <p className="font-semibold text-foreground">
                      {selectedSlot.distance}
                    </p>
                  </div>
                  <div>
                    <p className="text-muted-foreground mb-1">Price/Hour</p>
                    <p className="font-semibold text-foreground">
                      ₹{selectedSlot.price}
                    </p>
                  </div>
                  <div>
                    <p className="text-muted-foreground mb-1">Rating</p>
                    <p className="font-semibold text-secondary">
                      ⭐ {selectedSlot.rating}
                    </p>
                  </div>
                </div>
              </div>

              {/* Reservation Details Form */}
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-3">
                    Parking Date
                  </label>
                  <input
                    type="date"
                    value={reservationData.date}
                    onChange={(e) =>
                      setReservationData((prev) => ({
                        ...prev,
                        date: e.target.value,
                      }))
                    }
                    className="w-full px-4 py-3 rounded-lg border-2 border-border bg-background focus:border-primary focus:outline-none transition-colors"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-semibold text-foreground mb-3">
                      Start Time
                    </label>
                    <input
                      type="time"
                      value={reservationData.startTime}
                      onChange={(e) =>
                        setReservationData((prev) => ({
                          ...prev,
                          startTime: e.target.value,
                        }))
                      }
                      className="w-full px-4 py-3 rounded-lg border-2 border-border bg-background focus:border-primary focus:outline-none transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-foreground mb-3">
                      Duration (hours)
                    </label>
                    <input
                      type="number"
                      value={reservationData.duration}
                      onChange={handleDurationChange}
                      min="0.5"
                      max="24"
                      step="0.5"
                      className="w-full px-4 py-3 rounded-lg border-2 border-border bg-background focus:border-primary focus:outline-none transition-colors"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-foreground mb-3">
                    Vehicle Number
                  </label>
                  <input
                    type="text"
                    value={reservationData.vehicleNumber}
                    onChange={(e) =>
                      setReservationData((prev) => ({
                        ...prev,
                        vehicleNumber: e.target.value,
                      }))
                    }
                    placeholder="DL01AB1234"
                    className="w-full px-4 py-3 rounded-lg border-2 border-border bg-background focus:border-primary focus:outline-none transition-colors uppercase"
                  />
                </div>
              </div>
            </div>

            {/* EV Charging Option */}
            <div className="p-8 rounded-2xl bg-card border-2 border-border">
              <h3 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2">
                <Zap className="w-6 h-6 text-yellow-600" />
                Add EV Charging
              </h3>

              <div className="space-y-4">
                <label className="flex items-center gap-4 p-4 rounded-lg border-2 border-border hover:border-primary cursor-pointer transition-colors">
                  <input
                    type="checkbox"
                    checked={reservationData.includeEVCharging}
                    onChange={(e) =>
                      setReservationData((prev) => ({
                        ...prev,
                        includeEVCharging: e.target.checked,
                      }))
                    }
                    className="w-5 h-5 rounded border-border accent-primary"
                  />
                  <div>
                    <p className="font-semibold text-foreground">
                      Fast DC Charging (30 mins)
                    </p>
                    <p className="text-sm text-muted-foreground">
                      ₹80 • Adds 60 eco points
                    </p>
                  </div>
                </label>

                {reservationData.includeEVCharging && (
                  <div className="p-4 rounded-lg bg-green-50 border-2 border-green-200">
                    <p className="text-sm text-green-900">
                      ✓ Compatible EV charger available at this location
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Safety & Insurance */}
            <div className="p-8 rounded-2xl bg-card border-2 border-border">
              <h3 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2">
                <Shield className="w-6 h-6 text-primary" />
                Safety & Protection
              </h3>

              <div className="space-y-3">
                <label className="flex items-center gap-4 p-4 rounded-lg border-2 border-green-200 bg-green-50">
                  <input
                    type="checkbox"
                    defaultChecked
                    className="w-5 h-5 rounded border-green-200 accent-secondary"
                  />
                  <div>
                    <p className="font-semibold text-foreground">
                      Security Protection (Free)
                    </p>
                    <p className="text-sm text-muted-foreground">
                      24/7 monitoring and insurance
                    </p>
                  </div>
                </label>
              </div>
            </div>
          </div>

          {/* Right Column - Price Summary */}
          <div className="lg:col-span-1">
            <div className="p-8 rounded-2xl bg-card border-2 border-border sticky top-24">
              <h3 className="text-xl font-bold text-foreground mb-6">
                Price Summary
              </h3>

              <div className="space-y-4 mb-6 pb-6 border-b border-border">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">
                    {selectedSlot.price}₹ × {reservationData.duration} hours
                  </span>
                  <span className="font-semibold text-foreground">
                    ₹{baseCost.toFixed(2)}
                  </span>
                </div>

                {reservationData.includeEVCharging && (
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">EV Charging</span>
                    <span className="font-semibold text-foreground">
                      ₹{evChargingCost}
                    </span>
                  </div>
                )}

                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Tax & Charges</span>
                  <span className="font-semibold text-foreground">
                    ₹{(totalCost * 0.1).toFixed(2)}
                  </span>
                </div>
              </div>

              <div className="mb-8">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold text-foreground">
                    Total Amount
                  </span>
                  <span className="text-2xl font-bold text-primary">
                    ₹{(totalCost * 1.1).toFixed(2)}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground">
                  Including taxes and charges
                </p>
              </div>

              {/* Eco Points */}
              <div className="p-4 rounded-lg bg-green-50 border-2 border-green-200 mb-8">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-lg">🌱</span>
                  <span className="font-semibold text-green-900">
                    Eco Points Earned
                  </span>
                </div>
                <p className="text-2xl font-bold text-secondary mb-1">
                  +{estimatedEcoPoints}
                </p>
                <p className="text-xs text-green-700">
                  For choosing smart parking
                </p>
              </div>

              {/* CTA Buttons */}
              <div className="space-y-3">
                <button
                  onClick={handleConfirmReservation}
                  className="w-full py-3 px-4 rounded-lg bg-gradient-to-r from-primary to-blue-600 text-white font-semibold shadow-lg hover:shadow-xl hover:scale-105 transition-all"
                >
                  Reserve & Continue
                </button>

                <button
                  onClick={() => navigate("/prediction")}
                  className="w-full py-3 px-4 rounded-lg border-2 border-primary text-primary font-semibold hover:bg-blue-50 transition-all"
                >
                  Cancel
                </button>
              </div>

              {/* Info */}
              <p className="text-xs text-muted-foreground text-center mt-6">
                Secure payment. Your details are encrypted.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
