import { useNavigate } from "react-router-dom";
import { useState } from "react";
import {
  ArrowLeft,
  Leaf,
  Award,
  TrendingUp,
  Gift,
  Lock,
  Unlock,
  BarChart3,
  Target,
  ChevronRight,
} from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from "recharts";

export default function EcoWallet() {
  const navigate = useNavigate();
  const [selectedReward, setSelectedReward] = useState<string | null>(null);

  // Mock data
  const ecoStats = {
    totalPoints: 850,
    thisMonth: 180,
    carbonSaved: 125.5,
    currentRank: 12,
    tier: "Gold",
    nextTierPoints: 1000,
    progressPercent: (850 / 1000) * 100,
  };

  const carbonData = [
    { month: "Jan", savings: 45.2 },
    { month: "Feb", savings: 52.1 },
    { month: "Mar", savings: 48.9 },
    { month: "Apr", savings: 61.3 },
    { month: "May", savings: 58.7 },
    { month: "Jun", savings: 73.5 },
    { month: "Jul", savings: 89.2 },
    { month: "Aug", savings: 95.4 },
  ];

  const monthlyData = [
    { week: "Week 1", points: 40 },
    { week: "Week 2", points: 35 },
    { week: "Week 3", points: 52 },
    { week: "Week 4", points: 53 },
  ];

  const tiers = [
    {
      name: "Bronze",
      minPoints: 0,
      unlocked: true,
      rewards: "Basic rewards",
      color: "from-orange-600 to-orange-700",
    },
    {
      name: "Silver",
      minPoints: 500,
      unlocked: true,
      rewards: "Exclusive discounts",
      color: "from-gray-500 to-gray-600",
    },
    {
      name: "Gold",
      minPoints: 850,
      unlocked: true,
      rewards: "Priority parking",
      color: "from-yellow-500 to-yellow-600",
      isCurrent: true,
    },
    {
      name: "Green Hero",
      minPoints: 1500,
      unlocked: false,
      rewards: "Premium benefits",
      color: "from-green-600 to-green-700",
    },
    {
      name: "Eco Champion",
      minPoints: 2500,
      unlocked: false,
      rewards: "VIP status",
      color: "from-teal-600 to-teal-700",
    },
  ];

  const rewards = [
    {
      id: "RWD001",
      title: "Free Parking - 1 Hour",
      description: "One free hour at any ParkEase location",
      points: 300,
      available: true,
      category: "parking",
      icon: "🅿️",
    },
    {
      id: "RWD002",
      title: "10% Discount Voucher",
      description: "10% off on next 5 reservations",
      points: 200,
      available: true,
      category: "discount",
      icon: "🎟️",
    },
    {
      id: "RWD003",
      title: "Free EV Charging - 30 mins",
      description: "30 minutes of complimentary charging",
      points: 400,
      available: true,
      category: "charging",
      icon: "⚡",
    },
    {
      id: "RWD004",
      title: "Priority Booking Badge",
      description: "Priority access for 30 days",
      points: 500,
      available: false,
      category: "premium",
      icon: "👑",
    },
    {
      id: "RWD005",
      title: "Plant a Tree",
      description: "Donate to plant a tree in your name",
      points: 100,
      available: true,
      category: "sustainability",
      icon: "🌳",
    },
    {
      id: "RWD006",
      title: "Referral Bonus",
      description: "Invite friends and earn points together",
      points: 250,
      available: true,
      category: "bonus",
      icon: "👥",
    },
  ];

  const leaderboard = [
    { rank: 1, name: "Priya Kumar", points: 2540, avatar: "🏆" },
    { rank: 2, name: "Arjun Singh", points: 2180, avatar: "⭐" },
    { rank: 3, name: "Neha Sharma", points: 1920, avatar: "🌟" },
    { rank: 4, name: "Rohit Patel", points: 1750, avatar: "✨" },
    { rank: 5, name: "Anjali Desai", points: 1620, avatar: "💫" },
    { rank: 12, name: "You (John Doe)", points: 850, avatar: "👤", isCurrentUser: true },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-card border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-2 text-primary font-semibold hover:gap-3 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
            Back
          </button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-lg font-bold text-white">P</span>
            </div>
            <h1 className="text-2xl font-bold text-foreground hidden sm:block">
              ParkEase
            </h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Hero Stats */}
        <div className="mb-12 grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="p-8 rounded-2xl bg-gradient-to-br from-green-50 to-green-100 border-2 border-secondary">
            <div className="flex items-center justify-between mb-4">
              <Leaf className="w-8 h-8 text-secondary" />
              <span className="text-3xl">🌱</span>
            </div>
            <p className="text-muted-foreground text-sm mb-2">Total Eco Points</p>
            <p className="text-4xl font-bold text-foreground">{ecoStats.totalPoints}</p>
          </div>

          <div className="p-8 rounded-2xl bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-primary">
            <div className="flex items-center justify-between mb-4">
              <TrendingUp className="w-8 h-8 text-primary" />
              <span className="text-3xl">📈</span>
            </div>
            <p className="text-muted-foreground text-sm mb-2">This Month</p>
            <p className="text-4xl font-bold text-foreground">+{ecoStats.thisMonth}</p>
          </div>

          <div className="p-8 rounded-2xl bg-gradient-to-br from-orange-50 to-orange-100 border-2 border-orange-600">
            <div className="flex items-center justify-between mb-4">
              <Target className="w-8 h-8 text-orange-600" />
              <span className="text-3xl">🎯</span>
            </div>
            <p className="text-muted-foreground text-sm mb-2">CO₂ Saved</p>
            <p className="text-4xl font-bold text-foreground">
              {ecoStats.carbonSaved}kg
            </p>
          </div>

          <div className="p-8 rounded-2xl bg-gradient-to-br from-yellow-50 to-yellow-100 border-2 border-yellow-600">
            <div className="flex items-center justify-between mb-4">
              <Award className="w-8 h-8 text-yellow-600" />
              <span className="text-3xl">🏅</span>
            </div>
            <p className="text-muted-foreground text-sm mb-2">Your Rank</p>
            <p className="text-4xl font-bold text-foreground">#{ecoStats.currentRank}</p>
          </div>
        </div>

        {/* Progress to Next Tier */}
        <div className="mb-12 p-8 rounded-2xl bg-card border-2 border-border">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-2xl font-bold text-foreground mb-2">
                Current Tier: {ecoStats.tier} ⭐
              </h3>
              <p className="text-muted-foreground">
                {ecoStats.nextTierPoints - ecoStats.totalPoints} points to reach Green Hero
              </p>
            </div>
            <Award className="w-12 h-12 text-yellow-600" />
          </div>

          <div className="w-full bg-muted rounded-full h-3 mb-4 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-yellow-400 to-yellow-600 transition-all duration-500"
              style={{ width: `${Math.min(ecoStats.progressPercent, 100)}%` }}
            ></div>
          </div>

          <div className="flex items-center justify-between text-sm">
            <span className="font-semibold text-foreground">
              {ecoStats.totalPoints} / {ecoStats.nextTierPoints} points
            </span>
            <span className="text-muted-foreground">
              {Math.round(ecoStats.progressPercent)}% Complete
            </span>
          </div>
        </div>

        {/* Charts Section */}
        <div className="mb-12 grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Carbon Savings Trend */}
          <div className="p-8 rounded-2xl bg-card border-2 border-border">
            <h3 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2">
              <BarChart3 className="w-6 h-6 text-secondary" />
              Monthly Carbon Savings
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={carbonData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="month" stroke="var(--muted-foreground)" />
                <YAxis stroke="var(--muted-foreground)" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "var(--card)",
                    border: "2px solid var(--border)",
                    borderRadius: "8px",
                  }}
                />
                <Bar
                  dataKey="savings"
                  fill="hsl(112 40% 64%)"
                  radius={[8, 8, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Weekly Points Earned */}
          <div className="p-8 rounded-2xl bg-card border-2 border-border">
            <h3 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2">
              <TrendingUp className="w-6 h-6 text-primary" />
              Weekly Eco Points
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="week" stroke="var(--muted-foreground)" />
                <YAxis stroke="var(--muted-foreground)" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "var(--card)",
                    border: "2px solid var(--border)",
                    borderRadius: "8px",
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="points"
                  stroke="hsl(217 72% 51%)"
                  strokeWidth={3}
                  dot={{ fill: "hsl(217 72% 51%)", r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Tier System */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-foreground mb-8">Gamification Tiers</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {tiers.map((tier) => (
              <button
                key={tier.name}
                className={`p-6 rounded-2xl border-2 transition-all ${
                  tier.unlocked
                    ? "border-border hover:border-primary bg-card"
                    : "border-muted bg-muted/50"
                }`}
              >
                <div
                  className={`w-full h-20 rounded-lg bg-gradient-to-br ${tier.color} flex items-center justify-center mb-4 relative`}
                >
                  {!tier.unlocked && (
                    <Lock className="w-8 h-8 text-white absolute" />
                  )}
                  {tier.isCurrent && (
                    <span className="absolute top-2 right-2 px-2 py-1 rounded-full bg-yellow-400 text-xs font-bold">
                      Current
                    </span>
                  )}
                </div>

                <h4 className="font-bold text-foreground mb-1">{tier.name}</h4>
                <p className="text-xs text-muted-foreground mb-3">
                  {tier.minPoints}+ points
                </p>

                {tier.unlocked ? (
                  <div className="flex items-center gap-1 text-green-600 text-xs font-semibold">
                    <Unlock className="w-3 h-3" />
                    Unlocked
                  </div>
                ) : (
                  <div className="flex items-center gap-1 text-muted-foreground text-xs">
                    <Lock className="w-3 h-3" />
                    Locked
                  </div>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Rewards Section */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-foreground mb-8">
            Redeem Your Points
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {rewards.map((reward) => (
              <button
                key={reward.id}
                onClick={() => setSelectedReward(reward.id)}
                className={`p-6 rounded-2xl border-2 transition-all text-left ${
                  selectedReward === reward.id
                    ? "border-primary bg-blue-50 shadow-lg"
                    : "border-border hover:border-primary"
                } ${!reward.available && "opacity-60 cursor-not-allowed"}`}
              >
                <div className="flex items-start justify-between mb-4">
                  <span className="text-4xl">{reward.icon}</span>
                  {!reward.available ? (
                    <Lock className="w-5 h-5 text-muted-foreground" />
                  ) : (
                    <Unlock className="w-5 h-5 text-secondary" />
                  )}
                </div>

                <h4 className="font-bold text-foreground mb-1">
                  {reward.title}
                </h4>
                <p className="text-sm text-muted-foreground mb-4">
                  {reward.description}
                </p>

                <div className="flex items-center justify-between pt-4 border-t border-border">
                  <span className="text-lg font-bold text-primary">
                    {reward.points} pts
                  </span>
                  {reward.available && ecoStats.totalPoints >= reward.points ? (
                    <span className="text-xs font-bold text-secondary px-2 py-1 rounded-full bg-green-100">
                      Claimable
                    </span>
                  ) : (
                    <span className="text-xs text-muted-foreground">
                      {reward.points - ecoStats.totalPoints} more needed
                    </span>
                  )}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Leaderboard */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-foreground mb-8">
            Community Leaderboard
          </h2>
          <div className="rounded-2xl bg-card border-2 border-border overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-muted border-b border-border">
                  <tr>
                    <th className="px-6 py-4 text-left font-semibold text-foreground">
                      Rank
                    </th>
                    <th className="px-6 py-4 text-left font-semibold text-foreground">
                      User
                    </th>
                    <th className="px-6 py-4 text-right font-semibold text-foreground">
                      Eco Points
                    </th>
                    <th className="px-6 py-4 text-right font-semibold text-foreground">
                      Tier
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {leaderboard.map((user, idx) => (
                    <tr
                      key={user.rank}
                      className={`border-b border-border hover:bg-muted transition-colors ${
                        user.isCurrentUser ? "bg-blue-50" : ""
                      }`}
                    >
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <span className="text-2xl">{user.avatar}</span>
                          <span
                            className={`font-bold text-lg ${
                              user.rank <= 3
                                ? "text-yellow-600"
                                : "text-foreground"
                            }`}
                          >
                            #{user.rank}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className="font-semibold text-foreground">
                          {user.name}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <span className="font-bold text-primary">
                          {user.points}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <span className="px-3 py-1 rounded-full bg-yellow-100 text-yellow-900 text-sm font-semibold">
                          {user.points >= 1500
                            ? "Green Hero"
                            : user.points >= 850
                            ? "Gold"
                            : user.points >= 500
                            ? "Silver"
                            : "Bronze"}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="p-12 rounded-2xl bg-gradient-to-r from-green-50 to-green-100 border-2 border-secondary text-center">
          <h3 className="text-2xl font-bold text-foreground mb-4">
            Keep Parking Sustainably! 🌍
          </h3>
          <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
            Every eco-friendly parking choice contributes to a cleaner planet.
            Keep climbing the ranks and unlocking exclusive rewards!
          </p>
          <button
            onClick={() => navigate("/")}
            className="px-8 py-3 rounded-lg bg-gradient-to-r from-secondary to-green-600 text-white font-semibold hover:shadow-lg transition-all"
          >
            Find More Parking 🅿️
          </button>
        </div>
      </main>
    </div>
  );
}
