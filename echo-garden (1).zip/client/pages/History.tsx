import { useNavigate } from "react-router-dom";
import { useState } from "react";
import {
  ArrowLeft,
  MapPin,
  Clock,
  DollarSign,
  Star,
  Download,
  Filter,
  Search,
  ChevronRight,
  Zap,
} from "lucide-react";

export default function History() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [filterStatus, setFilterStatus] = useState<"all" | "completed" | "cancelled">("all");
  const [selectedSession, setSelectedSession] = useState<string | null>(null);

  const parkingSessions = [
    {
      id: "RES001",
      slotName: "Downtown Plaza - Level 2",
      location: "Connaught Place, Delhi",
      date: "2024-01-15",
      startTime: "10:00",
      endTime: "14:00",
      duration: 4,
      amount: 200,
      status: "completed",
      rating: 5,
      ecoPointsEarned: 12,
      vehicleNumber: "DL01AB1234",
      distance: "450m",
      confirmationNumber: "PK2024000145",
    },
    {
      id: "RES002",
      slotName: "Tech Hub Garage - Level 1",
      location: "Sector 62, Noida",
      date: "2024-01-14",
      startTime: "09:30",
      endTime: "17:30",
      duration: 8,
      amount: 320,
      status: "completed",
      rating: 4,
      ecoPointsEarned: 25,
      vehicleNumber: "DL01AB1234",
      distance: "850m",
      confirmationNumber: "PK2024000128",
      evCharging: true,
      chargingCost: 80,
    },
    {
      id: "RES003",
      slotName: "Green Park - Eco Parking",
      location: "Green Park, Delhi",
      date: "2024-01-13",
      startTime: "08:00",
      endTime: "09:30",
      duration: 1.5,
      amount: 67.5,
      status: "completed",
      rating: 5,
      ecoPointsEarned: 35,
      vehicleNumber: "DL01AB1234",
      distance: "380m",
      confirmationNumber: "PK2024000098",
    },
    {
      id: "RES004",
      slotName: "Corporate Tower - Basement",
      location: "Gurugram Business Park",
      date: "2024-01-10",
      startTime: "07:00",
      endTime: "18:00",
      duration: 11,
      amount: 385,
      status: "completed",
      rating: 4,
      ecoPointsEarned: 18,
      vehicleNumber: "DL01AB1234",
      distance: "2100m",
      confirmationNumber: "PK2024000067",
    },
    {
      id: "RES005",
      slotName: "Mall of India",
      location: "Sector 38, Noida",
      date: "2024-01-08",
      startTime: "14:00",
      endTime: "16:00",
      duration: 2,
      amount: 160,
      status: "cancelled",
      ecoPointsEarned: 0,
      vehicleNumber: "DL01AB1234",
      distance: "650m",
      confirmationNumber: "PK2024000045",
    },
    {
      id: "RES006",
      slotName: "Airport Parking",
      location: "IGI Airport, Delhi",
      date: "2024-01-05",
      startTime: "11:00",
      endTime: "14:30",
      duration: 3.5,
      amount: 420,
      status: "completed",
      rating: 5,
      ecoPointsEarned: 20,
      vehicleNumber: "DL01AB1234",
      distance: "1200m",
      confirmationNumber: "PK2024000012",
    },
  ];

  const filteredSessions = parkingSessions.filter((session) => {
    const matchesSearch =
      session.slotName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      session.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
      session.confirmationNumber.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesFilter =
      filterStatus === "all" || session.status === filterStatus;

    return matchesSearch && matchesFilter;
  });

  const stats = {
    totalSessions: parkingSessions.filter((s) => s.status === "completed").length,
    totalSpent: parkingSessions
      .filter((s) => s.status === "completed")
      .reduce((sum, s) => sum + s.amount, 0),
    totalEcoPoints: parkingSessions.reduce(
      (sum, s) => sum + s.ecoPointsEarned,
      0
    ),
    avgRating: (
      parkingSessions
        .filter((s) => s.rating)
        .reduce((sum, s) => sum + (s.rating || 0), 0) /
      parkingSessions.filter((s) => s.rating).length
    ).toFixed(1),
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-card border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-2 text-primary font-semibold hover:gap-3 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
            Back
          </button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-lg font-bold text-white">P</span>
            </div>
            <h1 className="text-2xl font-bold text-foreground hidden sm:block">
              ParkEase
            </h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Stats Cards */}
        <div className="mb-12 grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="p-6 rounded-2xl bg-card border-2 border-border">
            <div className="text-muted-foreground text-sm mb-2">
              Total Sessions
            </div>
            <p className="text-4xl font-bold text-foreground mb-1">
              {stats.totalSessions}
            </p>
            <p className="text-xs text-muted-foreground">Completed reservations</p>
          </div>

          <div className="p-6 rounded-2xl bg-card border-2 border-border">
            <div className="text-muted-foreground text-sm mb-2">Total Spent</div>
            <p className="text-4xl font-bold text-primary mb-1">
              ₹{stats.totalSpent.toFixed(2)}
            </p>
            <p className="text-xs text-muted-foreground">All time spending</p>
          </div>

          <div className="p-6 rounded-2xl bg-card border-2 border-border">
            <div className="text-muted-foreground text-sm mb-2">
              Eco Points Earned
            </div>
            <p className="text-4xl font-bold text-secondary mb-1">
              {stats.totalEcoPoints}
            </p>
            <p className="text-xs text-muted-foreground">Carbon positive impact</p>
          </div>

          <div className="p-6 rounded-2xl bg-card border-2 border-border">
            <div className="text-muted-foreground text-sm mb-2">Avg Rating</div>
            <p className="text-4xl font-bold text-yellow-600 mb-1">
              {stats.avgRating}⭐
            </p>
            <p className="text-xs text-muted-foreground">From rated sessions</p>
          </div>
        </div>

        {/* Search & Filter */}
        <div className="mb-8 space-y-4">
          <div className="flex flex-col sm:flex-row gap-4">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3.5 w-5 h-5 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search by location or confirmation number..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-3 rounded-lg border-2 border-border bg-card focus:border-primary focus:outline-none transition-colors"
              />
            </div>

            {/* Filter */}
            <div className="flex gap-2">
              <div className="flex items-center gap-2 bg-card rounded-lg border-2 border-border px-4">
                <Filter className="w-5 h-5 text-muted-foreground" />
                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value as any)}
                  className="py-2 bg-transparent focus:outline-none font-semibold text-foreground"
                >
                  <option value="all">All Sessions</option>
                  <option value="completed">Completed</option>
                  <option value="cancelled">Cancelled</option>
                </select>
              </div>

              <button className="p-3 rounded-lg border-2 border-border bg-card hover:border-primary transition-colors">
                <Download className="w-5 h-5 text-muted-foreground" />
              </button>
            </div>
          </div>

          <p className="text-sm text-muted-foreground">
            Showing {filteredSessions.length} session(s)
          </p>
        </div>

        {/* Sessions List */}
        <div className="space-y-4">
          {filteredSessions.length > 0 ? (
            filteredSessions.map((session) => (
              <button
                key={session.id}
                onClick={() =>
                  setSelectedSession(
                    selectedSession === session.id ? null : session.id
                  )
                }
                className={`w-full p-6 rounded-2xl border-2 transition-all text-left ${
                  selectedSession === session.id
                    ? "border-primary bg-blue-50 shadow-lg"
                    : "border-border hover:border-primary hover:shadow-md"
                } ${session.status === "cancelled" && "opacity-75"}`}
              >
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                  {/* Left - Session Info */}
                  <div className="flex-1">
                    <div className="flex items-start gap-4 mb-3">
                      <div className="w-12 h-12 rounded-lg bg-blue-100 flex items-center justify-center flex-shrink-0">
                        <MapPin className="w-6 h-6 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-bold text-foreground text-lg mb-1 line-clamp-1">
                          {session.slotName}
                        </h3>
                        <p className="text-sm text-muted-foreground line-clamp-1">
                          {session.location}
                        </p>
                      </div>
                    </div>

                    {/* Meta Info */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm">
                      <div>
                        <p className="text-muted-foreground mb-1">Date</p>
                        <p className="font-semibold text-foreground">
                          {session.date}
                        </p>
                      </div>
                      <div>
                        <p className="text-muted-foreground mb-1">Time</p>
                        <p className="font-semibold text-foreground">
                          {session.startTime} - {session.endTime}
                        </p>
                      </div>
                      <div>
                        <p className="text-muted-foreground mb-1">Duration</p>
                        <p className="font-semibold text-foreground">
                          {session.duration} hours
                        </p>
                      </div>
                      <div>
                        <p className="text-muted-foreground mb-1">Vehicle</p>
                        <p className="font-semibold text-foreground">
                          {session.vehicleNumber}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Right - Amount & Status */}
                  <div className="flex items-center gap-4 lg:flex-col lg:items-end">
                    <div className="text-right">
                      <p className="text-3xl font-bold text-primary">
                        ₹{session.amount}
                      </p>
                      <span
                        className={`inline-block px-3 py-1 rounded-full text-xs font-semibold mt-2 ${
                          session.status === "completed"
                            ? "bg-green-100 text-green-700"
                            : "bg-red-100 text-red-700"
                        }`}
                      >
                        {session.status === "completed" ? "✓ Completed" : "✕ Cancelled"}
                      </span>
                    </div>

                    {session.rating && (
                      <div className="flex items-center gap-1 text-yellow-600 font-semibold">
                        {Array(session.rating)
                          .fill(null)
                          .map((_, i) => (
                            <Star key={i} className="w-4 h-4 fill-yellow-600" />
                          ))}
                      </div>
                    )}
                  </div>

                  <ChevronRight
                    className={`w-6 h-6 text-muted-foreground transition-transform ${
                      selectedSession === session.id ? "rotate-90" : ""
                    }`}
                  />
                </div>

                {/* Expanded Details */}
                {selectedSession === session.id && (
                  <div className="mt-6 pt-6 border-t border-blue-200 space-y-4">
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">
                          Confirmation #
                        </p>
                        <p className="font-mono font-bold text-foreground">
                          {session.confirmationNumber}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Distance</p>
                        <p className="font-semibold text-foreground">
                          {session.distance}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">
                          Eco Points
                        </p>
                        <p className="font-bold text-secondary">
                          +{session.ecoPointsEarned}
                        </p>
                      </div>
                    </div>

                    {session.evCharging && (
                      <div className="p-3 rounded-lg bg-yellow-50 border border-yellow-200 flex items-center gap-2">
                        <Zap className="w-4 h-4 text-yellow-600" />
                        <span className="text-sm font-semibold text-yellow-900">
                          EV Charging: ₹{session.chargingCost}
                        </span>
                      </div>
                    )}

                    <div className="flex gap-3">
                      <button className="px-4 py-2 rounded-lg border-2 border-primary text-primary font-semibold hover:bg-blue-50 transition-all flex-1">
                        View Receipt
                      </button>
                      {session.status === "completed" && !session.rating && (
                        <button className="px-4 py-2 rounded-lg bg-primary text-white font-semibold hover:shadow-lg transition-all flex-1">
                          Rate Spot
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </button>
            ))
          ) : (
            <div className="text-center py-16">
              <div className="mb-4 flex justify-center">
                <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center">
                  <Search className="w-8 h-8 text-muted-foreground" />
                </div>
              </div>
              <h3 className="text-lg font-bold text-foreground mb-2">
                No sessions found
              </h3>
              <p className="text-muted-foreground">
                Try adjusting your search or filters
              </p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
