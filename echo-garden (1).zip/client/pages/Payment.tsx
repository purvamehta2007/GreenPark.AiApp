import { useNavigate } from "react-router-dom";
import { useState } from "react";
import {
  ArrowLeft,
  MapPin,
  Clock,
  DollarSign,
  Zap,
  Copy,
  Check,
  CreditCard,
  Smartphone,
  Wallet,
  AlertCircle,
} from "lucide-react";

export default function Payment() {
  const navigate = useNavigate();
  const [paymentMethod, setPaymentMethod] = useState<"upi" | "card" | "wallet" | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [copied, setCopied] = useState(false);

  const reservationDetails = {
    slotName: "Downtown Plaza - Level 2",
    location: "Connaught Place, Delhi",
    date: "2024-01-20",
    startTime: "14:00",
    duration: 2,
    vehicleNumber: "DL01AB1234",
    evCharging: true,
  };

  const pricing = {
    parking: 100,
    evCharging: 80,
    tax: 18,
    total: 198,
  };

  const confirmationNumber = "PK2024001425";
  const transactionId = "TXN20240120142500001";

  const paymentMethods = [
    {
      id: "upi",
      name: "UPI",
      icon: <Smartphone className="w-8 h-8" />,
      apps: ["GooglePay", "PhonePe", "Paytm"],
      description: "Fast & Secure",
    },
    {
      id: "card",
      name: "Debit / Credit Card",
      icon: <CreditCard className="w-8 h-8" />,
      description: "Visa, Mastercard",
    },
    {
      id: "wallet",
      name: "ParkEase Wallet",
      icon: <Wallet className="w-8 h-8" />,
      description: "Wallet Balance: ₹2,450",
    },
  ];

  const handlePayment = async () => {
    if (!paymentMethod) return;

    setIsProcessing(true);
    // Simulate payment processing
    await new Promise((resolve) => setTimeout(resolve, 2000));
    setIsProcessing(false);
    setIsSuccess(true);

    // Navigate to success after 4 seconds
    setTimeout(() => navigate("/"), 4000);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (isSuccess) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="max-w-2xl w-full">
          {/* Success Animation */}
          <div className="mb-8 flex justify-center">
            <div className="relative w-24 h-24">
              <div className="absolute inset-0 rounded-full bg-gradient-to-r from-green-400 to-green-600 animate-pulse"></div>
              <div className="absolute inset-2 rounded-full bg-card flex items-center justify-center">
                <Check className="w-12 h-12 text-green-600 animate-bounce" />
              </div>
            </div>
          </div>

          {/* Success Content */}
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-foreground mb-4">
              Parking Reserved!
            </h1>
            <p className="text-xl text-muted-foreground">
              Your spot is confirmed for {reservationDetails.date}
            </p>
          </div>

          {/* Confirmation Details */}
          <div className="p-8 rounded-2xl bg-card border-2 border-border mb-8">
            <div className="mb-6 pb-6 border-b border-border">
              <h3 className="font-semibold text-foreground mb-4">Reservation Details</h3>
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-foreground">
                      {reservationDetails.slotName}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {reservationDetails.location}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Clock className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-foreground">
                      {reservationDetails.date} at {reservationDetails.startTime}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Duration: {reservationDetails.duration} hours
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Wallet className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-foreground">
                      {reservationDetails.vehicleNumber}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Vehicle Number
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Confirmation Numbers */}
            <div className="space-y-3">
              <div>
                <p className="text-sm text-muted-foreground mb-2">Confirmation Number</p>
                <div className="flex items-center gap-2">
                  <code className="flex-1 p-3 rounded-lg bg-background border border-border font-mono font-bold text-foreground">
                    {confirmationNumber}
                  </code>
                  <button
                    onClick={() => copyToClipboard(confirmationNumber)}
                    className="p-3 rounded-lg border border-border hover:bg-background transition-colors"
                  >
                    {copied ? (
                      <Check className="w-5 h-5 text-secondary" />
                    ) : (
                      <Copy className="w-5 h-5 text-muted-foreground" />
                    )}
                  </button>
                </div>
              </div>

              <div>
                <p className="text-sm text-muted-foreground mb-2">Transaction ID</p>
                <code className="block p-3 rounded-lg bg-background border border-border font-mono text-sm text-foreground">
                  {transactionId}
                </code>
              </div>
            </div>
          </div>

          {/* Eco Rewards */}
          <div className="p-6 rounded-2xl bg-gradient-to-br from-green-50 to-green-100 border-2 border-secondary mb-8">
            <div className="flex items-center gap-3 mb-4">
              <span className="text-2xl">🌱</span>
              <div>
                <h4 className="font-bold text-foreground">Eco Points Earned!</h4>
                <p className="text-sm text-muted-foreground">For eco-friendly parking</p>
              </div>
            </div>
            <div className="text-3xl font-bold text-secondary">+180 points</div>
            <p className="text-sm text-green-700 mt-2">
              Join the sustainability movement
            </p>
          </div>

          {/* CTA */}
          <button
            onClick={() => navigate("/")}
            className="w-full py-3 px-6 rounded-lg bg-gradient-to-r from-primary to-blue-600 text-white font-semibold shadow-lg hover:shadow-xl transition-all"
          >
            Return to Home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-card border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <button
            onClick={() => navigate("/reservation")}
            className="flex items-center gap-2 text-primary font-semibold hover:gap-3 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
            Back
          </button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-lg font-bold text-white">P</span>
            </div>
            <h1 className="text-2xl font-bold text-foreground hidden sm:block">
              ParkEase
            </h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Payment Methods */}
          <div className="lg:col-span-2 space-y-8">
            {/* Parking Summary */}
            <div className="p-8 rounded-2xl bg-card border-2 border-border">
              <h2 className="text-2xl font-bold text-foreground mb-6">
                Parking Summary
              </h2>

              <div className="space-y-4 mb-6 pb-6 border-b border-border">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-lg bg-gradient-to-br from-blue-100 to-blue-200 flex items-center justify-center">
                    <MapPin className="w-8 h-8 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold text-foreground">
                      {reservationDetails.slotName}
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      {reservationDetails.location}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground mb-1">Date & Time</p>
                    <p className="font-semibold text-foreground">
                      {reservationDetails.date} {reservationDetails.startTime}
                    </p>
                  </div>
                  <div>
                    <p className="text-muted-foreground mb-1">Duration</p>
                    <p className="font-semibold text-foreground">
                      {reservationDetails.duration} hours
                    </p>
                  </div>
                  <div>
                    <p className="text-muted-foreground mb-1">Vehicle</p>
                    <p className="font-semibold text-foreground">
                      {reservationDetails.vehicleNumber}
                    </p>
                  </div>
                  <div>
                    <p className="text-muted-foreground mb-1">EV Charging</p>
                    <p className="font-semibold text-secondary">Yes</p>
                  </div>
                </div>
              </div>

              {/* Price Breakdown */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Parking (₹50 × 2 hrs)</span>
                  <span className="font-semibold text-foreground">₹{pricing.parking}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">EV Charging</span>
                  <span className="font-semibold text-foreground">₹{pricing.evCharging}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Tax & Charges</span>
                  <span className="font-semibold text-foreground">₹{pricing.tax}</span>
                </div>
                <div className="border-t border-border pt-2 flex items-center justify-between">
                  <span className="font-semibold text-foreground">Total</span>
                  <span className="text-2xl font-bold text-primary">₹{pricing.total}</span>
                </div>
              </div>
            </div>

            {/* Payment Method Selection */}
            <div className="p-8 rounded-2xl bg-card border-2 border-border">
              <h3 className="text-xl font-bold text-foreground mb-6">
                Select Payment Method
              </h3>

              <div className="space-y-4 mb-8">
                {paymentMethods.map((method) => (
                  <button
                    key={method.id}
                    onClick={() => setPaymentMethod(method.id as any)}
                    className={`w-full p-6 rounded-lg border-2 transition-all text-left ${
                      paymentMethod === method.id
                        ? "border-primary bg-blue-50"
                        : "border-border hover:border-primary"
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <div
                        className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                          paymentMethod === method.id
                            ? "bg-primary text-white"
                            : "bg-muted text-muted-foreground"
                        }`}
                      >
                        {method.icon}
                      </div>
                      <div className="flex-1">
                        <h4 className="font-bold text-foreground">
                          {method.name}
                        </h4>
                        <p className="text-sm text-muted-foreground">
                          {method.description}
                        </p>
                      </div>
                      <div
                        className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                          paymentMethod === method.id
                            ? "border-primary bg-primary"
                            : "border-border"
                        }`}
                      >
                        {paymentMethod === method.id && (
                          <Check className="w-3 h-3 text-white" />
                        )}
                      </div>
                    </div>

                    {method.id === "upi" && method.apps && (
                      <div className="mt-4 flex gap-2">
                        {method.apps.map((app) => (
                          <span
                            key={app}
                            className="px-3 py-1 rounded-full bg-muted text-muted-foreground text-xs font-semibold"
                          >
                            {app}
                          </span>
                        ))}
                      </div>
                    )}
                  </button>
                ))}
              </div>

              {/* Payment Details Form */}
              {paymentMethod && (
                <div className="p-6 rounded-lg border-2 border-blue-200 bg-blue-50">
                  {paymentMethod === "upi" && (
                    <div>
                      <label className="block text-sm font-semibold text-foreground mb-2">
                        Enter UPI ID
                      </label>
                      <input
                        type="text"
                        placeholder="yourname@upi"
                        className="w-full px-4 py-3 rounded-lg border-2 border-blue-200 bg-white focus:outline-none focus:border-primary"
                      />
                    </div>
                  )}

                  {paymentMethod === "card" && (
                    <div className="space-y-4">
                      <input
                        type="text"
                        placeholder="Card Number"
                        className="w-full px-4 py-3 rounded-lg border-2 border-blue-200 bg-white focus:outline-none focus:border-primary"
                      />
                      <div className="grid grid-cols-2 gap-4">
                        <input
                          type="text"
                          placeholder="MM/YY"
                          className="w-full px-4 py-3 rounded-lg border-2 border-blue-200 bg-white focus:outline-none focus:border-primary"
                        />
                        <input
                          type="text"
                          placeholder="CVV"
                          className="w-full px-4 py-3 rounded-lg border-2 border-blue-200 bg-white focus:outline-none focus:border-primary"
                        />
                      </div>
                    </div>
                  )}

                  {paymentMethod === "wallet" && (
                    <div className="p-4 rounded-lg bg-white border-2 border-green-200">
                      <p className="text-sm text-muted-foreground mb-2">
                        Available Balance
                      </p>
                      <p className="text-2xl font-bold text-secondary">₹2,450</p>
                      <p className="text-sm text-green-700 mt-2">
                        ✓ Sufficient funds available
                      </p>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Security Info */}
            <div className="p-6 rounded-lg bg-green-50 border-2 border-green-200 flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-green-700 flex-shrink-0 mt-0.5" />
              <div className="text-sm">
                <p className="font-semibold text-green-900 mb-1">
                  Secure & Encrypted
                </p>
                <p className="text-green-800">
                  All transactions are encrypted with 256-bit SSL security
                </p>
              </div>
            </div>
          </div>

          {/* Right Column - Payment Confirmation */}
          <div className="lg:col-span-1">
            <div className="p-8 rounded-2xl bg-card border-2 border-border sticky top-24">
              <h3 className="text-xl font-bold text-foreground mb-6">
                Payment Confirmation
              </h3>

              <div className="space-y-4 mb-8 pb-8 border-b border-border">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Amount</span>
                  <span className="text-2xl font-bold text-primary">
                    ₹{pricing.total}
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Method</span>
                  <span className="font-semibold text-foreground capitalize">
                    {paymentMethod || "Select method"}
                  </span>
                </div>
              </div>

              {/* Terms Checkbox */}
              <label className="flex items-start gap-3 mb-6">
                <input
                  type="checkbox"
                  defaultChecked
                  className="w-5 h-5 rounded border-border accent-primary mt-0.5"
                />
                <span className="text-sm text-muted-foreground">
                  I agree to the{" "}
                  <a href="#" className="text-primary font-semibold hover:underline">
                    Terms & Conditions
                  </a>{" "}
                  and{" "}
                  <a href="#" className="text-primary font-semibold hover:underline">
                    Privacy Policy
                  </a>
                </span>
              </label>

              {/* Payment Button */}
              <button
                onClick={handlePayment}
                disabled={!paymentMethod || isProcessing}
                className="w-full py-3 px-4 rounded-lg bg-gradient-to-r from-primary to-blue-600 text-white font-semibold shadow-lg hover:shadow-xl hover:scale-105 transition-all disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
              >
                {isProcessing ? (
                  <span className="flex items-center justify-center gap-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    Processing...
                  </span>
                ) : (
                  <>
                    <DollarSign className="w-5 h-5 inline-block mr-2" />
                    Pay ₹{pricing.total}
                  </>
                )}
              </button>

              {!paymentMethod && (
                <p className="text-xs text-muted-foreground text-center mt-4">
                  Select a payment method to continue
                </p>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
