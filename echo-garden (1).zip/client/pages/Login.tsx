import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Mail, Lock, Phone, Eye, EyeOff } from "lucide-react";

export default function Login() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<"signin" | "signup">("signin");
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    name: "",
    phone: "",
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock authentication - redirect to home
    localStorage.setItem("isAuthenticated", "true");
    navigate("/");
  };

  const handleSignUp = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock registration
    localStorage.setItem("isAuthenticated", "true");
    navigate("/");
  };

  const handleGoogleAuth = () => {
    // Mock Google OAuth
    localStorage.setItem("isAuthenticated", "true");
    navigate("/");
  };

  const handleOTPAuth = () => {
    // Mock OTP flow
    localStorage.setItem("isAuthenticated", "true");
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-background flex">
      {/* Left side - Branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-primary via-blue-500 to-primary-foreground flex-col items-center justify-center p-12 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-20 w-40 h-40 bg-white rounded-full blur-3xl"></div>
          <div className="absolute bottom-20 right-20 w-60 h-60 bg-white rounded-full blur-3xl"></div>
        </div>
        
        <div className="relative z-10 text-center">
          <div className="mb-8 flex items-center justify-center">
            <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center">
              <span className="text-2xl font-bold text-primary">P</span>
            </div>
          </div>
          <h1 className="text-4xl font-bold text-white mb-4">ParkEase</h1>
          <p className="text-xl text-white/90 font-light">
            Smart Parking Assistant
          </p>
          <div className="mt-12 space-y-6 text-left">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-lg bg-white/20 flex items-center justify-center flex-shrink-0 mt-1">
                <span className="text-white font-semibold">✓</span>
              </div>
              <div>
                <h3 className="text-white font-semibold">Find Parking Instantly</h3>
                <p className="text-white/80 text-sm">Real-time availability and predictions</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-lg bg-white/20 flex items-center justify-center flex-shrink-0 mt-1">
                <span className="text-white font-semibold">✓</span>
              </div>
              <div>
                <h3 className="text-white font-semibold">Earn Eco Points</h3>
                <p className="text-white/80 text-sm">Get rewarded for sustainable choices</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-lg bg-white/20 flex items-center justify-center flex-shrink-0 mt-1">
                <span className="text-white font-semibold">✓</span>
              </div>
              <div>
                <h3 className="text-white font-semibold">Share Your Space</h3>
                <p className="text-white/80 text-sm">Earn extra income from spare parking</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Right side - Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-6 sm:p-12">
        <div className="w-full max-w-md">
          {/* Mobile branding */}
          <div className="lg:hidden mb-8 text-center">
            <div className="flex items-center justify-center mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-primary to-blue-500 rounded-xl flex items-center justify-center">
                <span className="text-xl font-bold text-white">P</span>
              </div>
            </div>
            <h1 className="text-2xl font-bold text-foreground">ParkEase</h1>
            <p className="text-muted-foreground text-sm">Smart Parking Assistant</p>
          </div>

          {/* Tabs */}
          <div className="flex gap-4 mb-8">
            <button
              onClick={() => setActiveTab("signin")}
              className={`flex-1 py-3 px-4 rounded-lg font-semibold transition-all ${
                activeTab === "signin"
                  ? "bg-primary text-white shadow-lg"
                  : "bg-muted text-foreground hover:bg-border"
              }`}
            >
              Sign In
            </button>
            <button
              onClick={() => setActiveTab("signup")}
              className={`flex-1 py-3 px-4 rounded-lg font-semibold transition-all ${
                activeTab === "signup"
                  ? "bg-primary text-white shadow-lg"
                  : "bg-muted text-foreground hover:bg-border"
              }`}
            >
              Sign Up
            </button>
          </div>

          {/* Social Auth */}
          <div className="space-y-3 mb-8">
            <button
              onClick={handleGoogleAuth}
              className="w-full py-3 px-4 rounded-lg border-2 border-border bg-card hover:bg-muted transition-colors flex items-center justify-center gap-3 font-semibold text-foreground"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none">
                <path
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  fill="#4285F4"
                />
                <path
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  fill="#34A853"
                />
                <path
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                  fill="#FBBC05"
                />
                <path
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                  fill="#EA4335"
                />
              </svg>
              Continue with Google
            </button>

            <button
              onClick={handleOTPAuth}
              className="w-full py-3 px-4 rounded-lg border-2 border-border bg-card hover:bg-muted transition-colors flex items-center justify-center gap-3 font-semibold text-foreground"
            >
              <Phone className="w-5 h-5" />
              Continue with OTP
            </button>
          </div>

          {/* Divider */}
          <div className="relative mb-8">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-border"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-background text-muted-foreground">Or continue with email</span>
            </div>
          </div>

          {/* Form */}
          <form
            onSubmit={activeTab === "signin" ? handleSignIn : handleSignUp}
            className="space-y-4"
          >
            {activeTab === "signup" && (
              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">
                  Full Name
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  placeholder="John Doe"
                  className="w-full px-4 py-3 rounded-lg border-2 border-border bg-card focus:border-primary focus:outline-none transition-colors"
                  required
                />
              </div>
            )}

            <div>
              <label className="block text-sm font-semibold text-foreground mb-2">
                Email Address
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-3.5 w-5 h-5 text-muted-foreground" />
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  placeholder="you@example.com"
                  className="w-full pl-10 pr-4 py-3 rounded-lg border-2 border-border bg-card focus:border-primary focus:outline-none transition-colors"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-foreground mb-2">
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-3.5 w-5 h-5 text-muted-foreground" />
                <input
                  type={showPassword ? "text" : "password"}
                  name="password"
                  value={formData.password}
                  onChange={handleInputChange}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-10 py-3 rounded-lg border-2 border-border bg-card focus:border-primary focus:outline-none transition-colors"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-3.5 text-muted-foreground hover:text-foreground"
                >
                  {showPassword ? (
                    <EyeOff className="w-5 h-5" />
                  ) : (
                    <Eye className="w-5 h-5" />
                  )}
                </button>
              </div>
            </div>

            {activeTab === "signin" && (
              <div className="flex items-center justify-between">
                <label className="flex items-center gap-2">
                  <input type="checkbox" className="w-4 h-4 rounded border-border" />
                  <span className="text-sm text-muted-foreground">Remember me</span>
                </label>
                <a href="#" className="text-sm font-semibold text-primary hover:underline">
                  Forgot password?
                </a>
              </div>
            )}

            <button
              type="submit"
              className="w-full py-3 px-4 rounded-lg bg-gradient-to-r from-primary to-blue-600 text-white font-semibold shadow-lg hover:shadow-xl hover:scale-105 transition-all mt-6"
            >
              {activeTab === "signin" ? "Sign In" : "Create Account"}
            </button>

            <p className="text-center text-muted-foreground mt-4">
              {activeTab === "signin"
                ? "Don't have an account? "
                : "Already have an account? "}
              <button
                type="button"
                onClick={() =>
                  setActiveTab(activeTab === "signin" ? "signup" : "signin")
                }
                className="font-semibold text-primary hover:underline"
              >
                {activeTab === "signin" ? "Sign up" : "Sign in"}
              </button>
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}
