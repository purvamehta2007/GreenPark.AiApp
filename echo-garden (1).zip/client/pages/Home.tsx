import { useNavigate } from "react-router-dom";
import {
  MapPin,
  Search,
  Navigation,
  Zap,
  Leaf,
  Award,
  ChevronRight,
  Bell,
  Menu,
  History,
  Wallet as WalletIcon,
} from "lucide-react";
import { useState } from "react";

export default function Home() {
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleLogout = () => {
    localStorage.removeItem("isAuthenticated");
    navigate("/login");
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-card border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-lg font-bold text-white">P</span>
            </div>
            <h1 className="text-2xl font-bold text-foreground">ParkEase</h1>
          </div>

          <div className="flex items-center gap-4">
            <button className="relative p-2 text-muted-foreground hover:text-foreground transition-colors">
              <Bell className="w-6 h-6" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-destructive rounded-full"></span>
            </button>

            <button
              onClick={() => navigate("/profile")}
              className="w-10 h-10 rounded-full bg-gradient-to-br from-secondary to-green-600 text-white font-semibold flex items-center justify-center hover:shadow-lg transition-shadow"
            >
              J
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search Bar */}
        <div className="mb-8">
          <div className="relative">
            <Search className="absolute left-4 top-3.5 w-5 h-5 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search for parking near..."
              className="w-full pl-12 pr-6 py-3 rounded-xl border-2 border-border bg-card focus:border-primary focus:outline-none transition-colors shadow-sm"
            />
          </div>
        </div>

        {/* Map Section */}
        <div className="mb-12">
          <div className="rounded-2xl overflow-hidden shadow-lg bg-card border border-border">
            {/* Static Map Placeholder */}
            <div className="w-full h-96 bg-gradient-to-br from-blue-50 to-blue-100 flex items-center justify-center relative overflow-hidden">
              {/* Decorative map elements */}
              <div className="absolute inset-0">
                <svg
                  className="w-full h-full opacity-10"
                  viewBox="0 0 400 300"
                  preserveAspectRatio="none"
                >
                  <defs>
                    <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
                      <path
                        d="M 20 0 L 0 0 0 20"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="0.5"
                      />
                    </pattern>
                  </defs>
                  <rect width="400" height="300" fill="url(#grid)" />
                </svg>
              </div>

              <div className="relative z-10 text-center">
                <div className="mb-4 flex justify-center">
                  <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center shadow-lg">
                    <MapPin className="w-8 h-8 text-white" />
                  </div>
                </div>
                <h3 className="text-xl font-bold text-foreground mb-2">
                  Real-time Parking Map
                </h3>
                <p className="text-muted-foreground mb-6 max-w-xs">
                  Live parking availability and slots near you
                </p>
                <button
                  onClick={() => navigate("/prediction")}
                  className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-white rounded-lg font-semibold hover:shadow-lg hover:scale-105 transition-all"
                >
                  <Navigation className="w-5 h-5" />
                  View on Map
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Find Parking CTA */}
        <div className="mb-12">
          <button
            onClick={() => navigate("/prediction")}
            className="w-full py-6 px-8 rounded-xl bg-gradient-to-r from-primary to-blue-600 text-white font-bold text-lg shadow-xl hover:shadow-2xl hover:scale-105 transition-all flex items-center justify-center gap-3"
          >
            <Search className="w-6 h-6" />
            Find Parking Now
          </button>
        </div>

        {/* Quick Glance Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {/* Nearest Available Slots */}
          <button
            onClick={() => navigate("/prediction")}
            className="p-6 rounded-2xl bg-card border-2 border-border hover:border-primary hover:shadow-lg transition-all group cursor-pointer"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center group-hover:bg-blue-200 transition-colors">
                <MapPin className="w-6 h-6 text-primary" />
              </div>
              <span className="px-3 py-1 bg-green-100 text-secondary rounded-full text-xs font-semibold">
                8 Available
              </span>
            </div>
            <h3 className="font-bold text-foreground mb-1">Nearest Slots</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Within 500m radius
            </p>
            <div className="flex items-center gap-2 text-primary font-semibold">
              View Details
              <ChevronRight className="w-4 h-4" />
            </div>
          </button>

          {/* Eco Points Wallet */}
          <button
            onClick={() => navigate("/eco-wallet")}
            className="p-6 rounded-2xl bg-card border-2 border-border hover:border-secondary hover:shadow-lg transition-all group cursor-pointer"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center group-hover:bg-green-200 transition-colors">
                <Leaf className="w-6 h-6 text-secondary" />
              </div>
              <span className="px-3 py-1 bg-green-100 text-secondary rounded-full text-xs font-semibold">
                +850 Points
              </span>
            </div>
            <h3 className="font-bold text-foreground mb-1">Eco Points</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Earned from smart choices
            </p>
            <div className="flex items-center gap-2 text-secondary font-semibold">
              View Wallet
              <ChevronRight className="w-4 h-4" />
            </div>
          </button>

          {/* EV Charging Nearby */}
          <button
            onClick={() => navigate("/prediction")}
            className="p-6 rounded-2xl bg-card border-2 border-border hover:border-primary hover:shadow-lg transition-all group cursor-pointer"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center group-hover:bg-blue-200 transition-colors">
                <Zap className="w-6 h-6 text-primary" />
              </div>
              <span className="px-3 py-1 bg-yellow-100 text-orange-600 rounded-full text-xs font-semibold">
                3 Nearby
              </span>
            </div>
            <h3 className="font-bold text-foreground mb-1">EV Charging</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Fast chargers available
            </p>
            <div className="flex items-center gap-2 text-primary font-semibold">
              Find Chargers
              <ChevronRight className="w-4 h-4" />
            </div>
          </button>
        </div>

        {/* Features Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          {/* Parking Prediction */}
          <button
            onClick={() => navigate("/prediction")}
            className="p-8 rounded-2xl bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-primary hover:shadow-lg transition-all group cursor-pointer"
          >
            <div className="w-14 h-14 bg-primary rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <Award className="w-7 h-7 text-white" />
            </div>
            <h3 className="text-xl font-bold text-foreground mb-2">
              Parking Prediction
            </h3>
            <p className="text-muted-foreground mb-6">
              AI-powered predictions for next available slots in the next 30 minutes
            </p>
            <div className="flex items-center gap-2 text-primary font-semibold">
              View Predictions
              <ChevronRight className="w-5 h-5" />
            </div>
          </button>

          {/* Dynamic Offset */}
          <button
            onClick={() => navigate("/dynamic-offset")}
            className="p-8 rounded-2xl bg-gradient-to-br from-green-50 to-green-100 border-2 border-secondary hover:shadow-lg transition-all group cursor-pointer"
          >
            <div className="w-14 h-14 bg-secondary rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <Leaf className="w-7 h-7 text-white" />
            </div>
            <h3 className="text-xl font-bold text-foreground mb-2">
              Eco-Smart Offset
            </h3>
            <p className="text-muted-foreground mb-6">
              Choose less congested zones and earn extra eco rewards
            </p>
            <div className="flex items-center gap-2 text-secondary font-semibold">
              Earn Rewards
              <ChevronRight className="w-5 h-5" />
            </div>
          </button>
        </div>

        {/* Shared Parking Section */}
        <div className="p-8 rounded-2xl bg-card border-2 border-border hover:shadow-lg transition-all mb-12">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h3 className="text-xl font-bold text-foreground mb-2">
                Share Your Parking
              </h3>
              <p className="text-muted-foreground">
                Earn extra income by sharing your spare parking space
              </p>
            </div>
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <span className="text-xl">🏠</span>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6">
            <button
              onClick={() => navigate("/shared-parking")}
              className="py-3 px-4 rounded-lg bg-primary text-white font-semibold hover:shadow-lg transition-all"
            >
              List My Space
            </button>
            <button
              onClick={() => navigate("/shared-parking")}
              className="py-3 px-4 rounded-lg border-2 border-primary text-primary font-semibold hover:bg-blue-50 transition-all"
            >
              Browse Spaces
            </button>
          </div>
        </div>

        {/* Quick Links Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          {/* History */}
          <button
            onClick={() => navigate("/history")}
            className="p-8 rounded-2xl bg-card border-2 border-border hover:border-primary hover:shadow-lg transition-all text-left group"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="w-14 h-14 bg-blue-100 rounded-lg flex items-center justify-center group-hover:bg-blue-200 transition-colors">
                <History className="w-7 h-7 text-primary" />
              </div>
              <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:translate-x-1 transition-transform" />
            </div>
            <h3 className="text-xl font-bold text-foreground mb-2">
              Parking History
            </h3>
            <p className="text-muted-foreground">
              View past reservations and earnings
            </p>
          </button>

          {/* Wallet */}
          <button
            onClick={() => navigate("/wallet")}
            className="p-8 rounded-2xl bg-card border-2 border-border hover:border-secondary hover:shadow-lg transition-all text-left group"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="w-14 h-14 bg-green-100 rounded-lg flex items-center justify-center group-hover:bg-green-200 transition-colors">
                <WalletIcon className="w-7 h-7 text-secondary" />
              </div>
              <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:translate-x-1 transition-transform" />
            </div>
            <h3 className="text-xl font-bold text-foreground mb-2">
              Wallet & Transactions
            </h3>
            <p className="text-muted-foreground">
              Manage balance and payment methods
            </p>
          </button>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-card mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold text-foreground mb-4">ParkEase</h4>
              <p className="text-muted-foreground text-sm">
                Smart parking for everyone
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">Features</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-primary">
                    Find Parking
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary">
                    Eco Rewards
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary">
                    Share Space
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-primary">
                    Help Center
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary">
                    Contact Us
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary">
                    FAQ
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-primary">
                    Privacy Policy
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary">
                    Terms of Service
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 flex flex-col sm:flex-row justify-between items-center">
            <p className="text-muted-foreground text-sm">
              © 2024 ParkEase. All rights reserved.
            </p>
            <div className="flex gap-4 mt-4 sm:mt-0">
              <a
                href="#"
                className="text-muted-foreground hover:text-primary transition-colors"
              >
                Twitter
              </a>
              <a
                href="#"
                className="text-muted-foreground hover:text-primary transition-colors"
              >
                Facebook
              </a>
              <a
                href="#"
                className="text-muted-foreground hover:text-primary transition-colors"
              >
                Instagram
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
