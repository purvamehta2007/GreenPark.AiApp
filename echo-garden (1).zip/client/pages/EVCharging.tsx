import { useNavigate } from "react-router-dom";
import { useState } from "react";
import {
  ArrowLeft,
  MapPin,
  Zap,
  Clock,
  DollarSign,
  Navigation,
  Battery,
  AlertCircle,
  CheckCircle,
} from "lucide-react";

export default function EVCharging() {
  const navigate = useNavigate();
  const [selectedCharger, setSelectedCharger] = useState<string | null>(null);
  const [chargingDuration, setChargingDuration] = useState(30);

  const evChargers = [
    {
      id: "CH001",
      name: "Fast DC Charger - Level 1",
      location: "Downtown Plaza - Level 2",
      distance: "Same Location",
      power: "150 kW",
      type: "DC Fast Charging",
      availability: "2/3 available",
      price: 80,
      time: 30,
      compatibility: "Tesla, BMW, Hyundai, Audi",
      rating: 4.8,
      waitTime: "~5 mins",
      description: "Ultra-fast DC charging",
    },
    {
      id: "CH002",
      name: "AC Charger - Level 2",
      location: "Downtown Plaza - Basement",
      distance: "450m away",
      power: "22 kW",
      type: "AC Charging",
      availability: "5/5 available",
      price: 45,
      time: 60,
      compatibility: "All EVs",
      rating: 4.3,
      waitTime: "No wait",
      description: "Standard AC charging",
    },
    {
      id: "CH003",
      name: "Super Fast Charger",
      location: "Tech Hub Garage",
      distance: "850m away",
      power: "350 kW",
      type: "DC Ultra Fast",
      availability: "1/2 available",
      price: 120,
      time: 20,
      compatibility: "Latest EVs (2023+)",
      rating: 4.9,
      waitTime: "~15 mins",
      description: "Latest technology charger",
    },
  ];

  const handleChargerSelect = (chargerId: string) => {
    setSelectedCharger(chargerId);
  };

  const handleNavigate = () => {
    // Mock navigation - in real app would open maps
    alert("Opening Google Maps for directions...");
  };

  const handleAddCharging = () => {
    // Add to reservation and go back to reservation page
    navigate("/reservation");
  };

  const selectedChargerData = evChargers.find((c) => c.id === selectedCharger);
  const totalCost = selectedChargerData
    ? selectedChargerData.price * (chargingDuration / selectedChargerData.time)
    : 0;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-card border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <button
            onClick={() => navigate("/reservation")}
            className="flex items-center gap-2 text-primary font-semibold hover:gap-3 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
            Back
          </button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-lg font-bold text-white">P</span>
            </div>
            <h1 className="text-2xl font-bold text-foreground hidden sm:block">
              ParkEase
            </h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Page Header */}
        <div className="mb-12">
          <h1 className="text-4xl font-bold text-foreground mb-4 flex items-center gap-3">
            <Zap className="w-10 h-10 text-yellow-600" />
            EV Charging Solutions
          </h1>
          <p className="text-xl text-muted-foreground">
            Find and book compatible EV chargers near your parking spot
          </p>
        </div>

        {/* Current Reservation Info */}
        <div className="mb-12 p-6 rounded-2xl bg-gradient-to-r from-blue-50 to-blue-100 border-2 border-primary">
          <div className="flex items-start gap-4">
            <Battery className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
            <div className="flex-1">
              <h3 className="font-bold text-foreground mb-2">Your Parking Slot</h3>
              <p className="text-muted-foreground">
                Downtown Plaza - Level 2 • Jan 20, 2024 at 14:00 • 2 hours
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Chargers List */}
          <div className="lg:col-span-2">
            <h2 className="text-2xl font-bold text-foreground mb-6">
              Available Chargers Nearby
            </h2>

            <div className="space-y-4">
              {evChargers.map((charger) => (
                <button
                  key={charger.id}
                  onClick={() => handleChargerSelect(charger.id)}
                  className={`w-full p-6 rounded-2xl border-2 transition-all text-left ${
                    selectedCharger === charger.id
                      ? "border-primary bg-blue-50 shadow-lg"
                      : "border-border hover:border-primary hover:shadow-md"
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4 mb-4">
                    <div className="flex-1">
                      <h3 className="font-bold text-foreground text-lg mb-2">
                        {charger.name}
                      </h3>
                      <div className="flex flex-wrap gap-3 text-sm mb-3">
                        <span className="flex items-center gap-1 text-muted-foreground">
                          <MapPin className="w-4 h-4" />
                          {charger.location}
                        </span>
                        <span className="flex items-center gap-1 text-muted-foreground">
                          <Navigation className="w-4 h-4" />
                          {charger.distance}
                        </span>
                      </div>

                      {/* Stats Row */}
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm">
                        <div>
                          <p className="text-muted-foreground mb-1">Power</p>
                          <p className="font-semibold text-foreground">
                            {charger.power}
                          </p>
                        </div>
                        <div>
                          <p className="text-muted-foreground mb-1">Time</p>
                          <p className="font-semibold text-foreground">
                            {charger.time} mins
                          </p>
                        </div>
                        <div>
                          <p className="text-muted-foreground mb-1">
                            Availability
                          </p>
                          <p className="font-semibold text-green-600">
                            {charger.availability}
                          </p>
                        </div>
                        <div>
                          <p className="text-muted-foreground mb-1">Rating</p>
                          <p className="font-semibold text-secondary">
                            ⭐ {charger.rating}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Selection Indicator */}
                    <div className="flex flex-col items-end gap-3">
                      <div
                        className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${
                          selectedCharger === charger.id
                            ? "border-primary bg-primary"
                            : "border-border"
                        }`}
                      >
                        {selectedCharger === charger.id && (
                          <CheckCircle className="w-5 h-5 text-white" />
                        )}
                      </div>
                      <span className="text-primary font-bold text-lg">
                        ₹{charger.price}
                      </span>
                    </div>
                  </div>

                  {/* Details */}
                  {selectedCharger === charger.id && (
                    <div className="mt-4 pt-4 border-t border-blue-200 space-y-3">
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">
                          Type
                        </p>
                        <p className="font-semibold text-foreground">
                          {charger.type} • {charger.description}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">
                          Compatible Vehicles
                        </p>
                        <p className="font-semibold text-foreground">
                          {charger.compatibility}
                        </p>
                      </div>
                      <div className="flex items-center gap-3 text-sm">
                        <span className="px-3 py-1 rounded-full bg-blue-100 text-primary font-semibold">
                          Wait: {charger.waitTime}
                        </span>
                      </div>
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Right Column - Booking Summary */}
          {selectedChargerData && (
            <div className="lg:col-span-1">
              <div className="p-8 rounded-2xl bg-card border-2 border-border sticky top-24">
                <h3 className="text-xl font-bold text-foreground mb-6">
                  Charging Summary
                </h3>

                <div className="space-y-4 mb-8 pb-8 border-b border-border">
                  <div>
                    <p className="text-sm text-muted-foreground mb-2">Charger</p>
                    <p className="font-bold text-foreground">
                      {selectedChargerData.name}
                    </p>
                  </div>

                  <div>
                    <p className="text-sm text-muted-foreground mb-2">
                      Charging Duration
                    </p>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() =>
                          setChargingDuration(Math.max(15, chargingDuration - 15))
                        }
                        className="px-3 py-2 rounded border border-border hover:bg-muted"
                      >
                        −
                      </button>
                      <input
                        type="range"
                        min="15"
                        max="120"
                        step="15"
                        value={chargingDuration}
                        onChange={(e) =>
                          setChargingDuration(parseInt(e.target.value))
                        }
                        className="flex-1 h-2 bg-border rounded-lg appearance-none cursor-pointer accent-primary"
                      />
                      <button
                        onClick={() =>
                          setChargingDuration(
                            Math.min(120, chargingDuration + 15)
                          )
                        }
                        className="px-3 py-2 rounded border border-border hover:bg-muted"
                      >
                        +
                      </button>
                    </div>
                    <p className="text-center font-bold text-lg text-foreground mt-2">
                      {chargingDuration} mins
                    </p>
                  </div>

                  <div>
                    <p className="text-sm text-muted-foreground mb-2">
                      Estimated Time to Full
                    </p>
                    <p className="font-bold text-foreground">
                      {Math.ceil(
                        (chargingDuration / selectedChargerData.time) * 100
                      )}
                      % charge
                    </p>
                  </div>
                </div>

                {/* Pricing */}
                <div className="space-y-2 mb-8 pb-8 border-b border-border">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">
                      ₹{selectedChargerData.price} × {chargingDuration} mins
                    </span>
                    <span className="font-bold text-foreground">
                      ₹{totalCost.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-foreground">Total</span>
                    <span className="text-2xl font-bold text-primary">
                      ₹{totalCost.toFixed(2)}
                    </span>
                  </div>
                </div>

                {/* Eco Points */}
                <div className="p-4 rounded-lg bg-green-50 border-2 border-green-200 mb-8">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-lg">🌱</span>
                    <span className="font-semibold text-green-900">
                      Eco Bonus
                    </span>
                  </div>
                  <p className="text-xl font-bold text-secondary">
                    +{Math.floor(totalCost * 0.75)} points
                  </p>
                  <p className="text-xs text-green-700 mt-1">
                    For EV charging with us
                  </p>
                </div>

                {/* CTA Buttons */}
                <div className="space-y-3">
                  <button
                    onClick={handleNavigate}
                    className="w-full py-3 px-4 rounded-lg border-2 border-primary text-primary font-semibold hover:bg-blue-50 transition-all flex items-center justify-center gap-2"
                  >
                    <Navigation className="w-5 h-5" />
                    Navigate
                  </button>

                  <button
                    onClick={handleAddCharging}
                    className="w-full py-3 px-4 rounded-lg bg-gradient-to-r from-primary to-blue-600 text-white font-semibold shadow-lg hover:shadow-xl hover:scale-105 transition-all flex items-center justify-center gap-2"
                  >
                    <CheckCircle className="w-5 h-5" />
                    Add to Reservation
                  </button>
                </div>

                <p className="text-xs text-muted-foreground text-center mt-6">
                  Charger can be changed later
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Benefits Section */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-xl bg-card border-2 border-border text-center">
            <Zap className="w-8 h-8 text-yellow-600 mx-auto mb-3" />
            <h4 className="font-bold text-foreground mb-2">Fast Charging</h4>
            <p className="text-sm text-muted-foreground">
              Charge up to 80% in under 30 minutes
            </p>
          </div>

          <div className="p-6 rounded-xl bg-card border-2 border-border text-center">
            <DollarSign className="w-8 h-8 text-green-600 mx-auto mb-3" />
            <h4 className="font-bold text-foreground mb-2">Eco Points</h4>
            <p className="text-sm text-muted-foreground">
              Earn extra rewards for sustainable choices
            </p>
          </div>

          <div className="p-6 rounded-xl bg-card border-2 border-border text-center">
            <Shield className="w-8 h-8 text-primary mx-auto mb-3" />
            <h4 className="font-bold text-foreground mb-2">Safe & Secure</h4>
            <p className="text-sm text-muted-foreground">
              All chargers are monitored 24/7
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
