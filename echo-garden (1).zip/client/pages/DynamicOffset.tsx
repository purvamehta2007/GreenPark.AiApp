import { useNavigate } from "react-router-dom";
import { ArrowLeft, MapPin, Leaf, TrendingDown, Award } from "lucide-react";

export default function DynamicOffset() {
  const navigate = useNavigate();

  const slotComparisons = [
    {
      label: "Slot A",
      distance: "50m away",
      status: "Full",
      congestion: "100%",
      reward: "0 eco points",
      color: "from-red-50 to-red-100",
      borderColor: "border-destructive",
    },
    {
      label: "Slot B",
      distance: "200m away",
      status: "Available",
      congestion: "45%",
      reward: "₹15 + 5 eco points",
      color: "from-green-50 to-green-100",
      borderColor: "border-secondary",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-card border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-2 text-primary font-semibold hover:gap-3 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
            Back
          </button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-lg font-bold text-white">P</span>
            </div>
            <h1 className="text-2xl font-bold text-foreground hidden sm:block">
              ParkEase
            </h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-foreground mb-4 flex items-center justify-center gap-3">
            <TrendingDown className="w-10 h-10 text-secondary" />
            Dynamic Demand Offset
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Compare parking options and choose less congested zones to earn extra rewards
          </p>
        </div>

        {/* Side-by-Side Comparison */}
        <div className="mb-12 grid grid-cols-1 md:grid-cols-2 gap-8">
          {slotComparisons.map((slot, idx) => (
            <button
              key={idx}
              onClick={idx === 1 ? () => navigate("/reservation") : undefined}
              disabled={idx === 0}
              className={`p-8 rounded-2xl border-2 ${slot.borderColor} bg-gradient-to-br ${slot.color} transition-all ${
                idx === 0 ? "opacity-60 cursor-not-allowed" : "hover:shadow-xl hover:scale-105 cursor-pointer"
              }`}
            >
              <div className="text-left">
                <h3 className="text-2xl font-bold text-foreground mb-4">
                  {slot.label}
                </h3>

                <div className="space-y-4 mb-8">
                  <div className="flex items-center gap-3">
                    <MapPin className="w-5 h-5 text-muted-foreground" />
                    <span className="font-semibold text-foreground">
                      {slot.distance}
                    </span>
                  </div>

                  <div>
                    <p className="text-sm text-muted-foreground mb-2">Status</p>
                    <p
                      className={`text-lg font-bold ${
                        idx === 0
                          ? "text-destructive"
                          : "text-secondary"
                      }`}
                    >
                      {slot.status}
                    </p>
                  </div>

                  <div>
                    <p className="text-sm text-muted-foreground mb-2">
                      Congestion Level
                    </p>
                    <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
                      <div
                        className={`h-full ${
                          idx === 0
                            ? "bg-destructive"
                            : "bg-secondary"
                        }`}
                        style={{
                          width: slot.congestion,
                        }}
                      ></div>
                    </div>
                    <p className="text-sm font-semibold text-foreground mt-2">
                      {slot.congestion}
                    </p>
                  </div>
                </div>

                {idx === 1 && (
                  <div className="p-4 rounded-lg bg-white/50 border-2 border-secondary mb-8">
                    <div className="flex items-center gap-2 mb-2">
                      <Award className="w-5 h-5 text-secondary" />
                      <span className="font-bold text-foreground">
                        Extra Reward
                      </span>
                    </div>
                    <p className="text-lg font-bold text-secondary">
                      {slot.reward}
                    </p>
                  </div>
                )}

                {idx === 1 && (
                  <button className="w-full py-3 px-4 rounded-lg bg-gradient-to-r from-secondary to-green-600 text-white font-semibold hover:shadow-lg transition-all">
                    Choose This Spot & Earn 🌱
                  </button>
                )}
              </div>
            </button>
          ))}
        </div>

        {/* Why Choose Eco-Smart */}
        <div className="p-8 rounded-2xl bg-card border-2 border-border mb-12">
          <h2 className="text-2xl font-bold text-foreground mb-8 flex items-center gap-2">
            <Leaf className="w-8 h-8 text-secondary" />
            Why Choose Eco-Smart Offset?
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 rounded-xl bg-green-50 border-2 border-secondary/20">
              <div className="text-3xl mb-3">🌍</div>
              <h4 className="font-bold text-foreground mb-2">Reduce Congestion</h4>
              <p className="text-muted-foreground text-sm">
                Choosing less congested zones reduces overall parking demand
              </p>
            </div>

            <div className="p-6 rounded-xl bg-green-50 border-2 border-secondary/20">
              <div className="text-3xl mb-3">💰</div>
              <h4 className="font-bold text-foreground mb-2">Earn More</h4>
              <p className="text-muted-foreground text-sm">
                Get rewarded with eco points and cashback for smart choices
              </p>
            </div>

            <div className="p-6 rounded-xl bg-green-50 border-2 border-secondary/20">
              <div className="text-3xl mb-3">♻️</div>
              <h4 className="font-bold text-foreground mb-2">Save Environment</h4>
              <p className="text-muted-foreground text-sm">
                Contribute to a sustainable future with every parking choice
              </p>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-xl text-center bg-card border-2 border-border">
            <p className="text-4xl font-bold text-primary mb-2">2.5k</p>
            <p className="text-muted-foreground">Users Choosing Eco</p>
          </div>

          <div className="p-6 rounded-xl text-center bg-card border-2 border-border">
            <p className="text-4xl font-bold text-secondary mb-2">45k</p>
            <p className="text-muted-foreground">CO₂ Saved (kg)</p>
          </div>

          <div className="p-6 rounded-xl text-center bg-card border-2 border-border">
            <p className="text-4xl font-bold text-primary mb-2">₹125k</p>
            <p className="text-muted-foreground">Rewards Distributed</p>
          </div>
        </div>
      </main>
    </div>
  );
}
