import { useNavigate } from "react-router-dom";
import { useState } from "react";
import {
  ArrowLeft,
  Plus,
  Send,
  CreditCard,
  DollarSign,
  TrendingUp,
  Filter,
  Download,
  Zap,
  ArrowUpRight,
  ArrowDownLeft,
} from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

export default function Wallet() {
  const navigate = useNavigate();
  const [isAddingFunds, setIsAddingFunds] = useState(false);
  const [fundAmount, setFundAmount] = useState("");
  const [filterType, setFilterType] = useState<"all" | "credit" | "debit">("all");

  const walletBalance = 2450;
  const totalEcoPoints = 850;

  const balanceHistory = [
    { month: "Jan", balance: 1200 },
    { month: "Feb", balance: 1450 },
    { month: "Mar", balance: 1350 },
    { month: "Apr", balance: 1800 },
    { month: "May", balance: 2100 },
    { month: "Jun", balance: 2300 },
    { month: "Jul", balance: 2150 },
    { month: "Aug", balance: 2450 },
  ];

  const transactions = [
    {
      id: "TXN001",
      type: "debit",
      description: "Parking - Downtown Plaza",
      amount: 200,
      date: "2024-01-15",
      time: "14:00",
      icon: "🅿️",
    },
    {
      id: "TXN002",
      type: "credit",
      description: "Wallet Top-up",
      amount: 500,
      date: "2024-01-14",
      time: "10:30",
      icon: "➕",
    },
    {
      id: "TXN003",
      type: "debit",
      description: "EV Charging - Tech Hub",
      amount: 80,
      date: "2024-01-13",
      time: "09:45",
      icon: "⚡",
    },
    {
      id: "TXN004",
      type: "debit",
      description: "Parking - Airport",
      amount: 420,
      date: "2024-01-12",
      time: "11:20",
      icon: "🅿️",
    },
    {
      id: "TXN005",
      type: "credit",
      description: "Reward Redemption - Eco Points",
      amount: 250,
      date: "2024-01-10",
      time: "16:00",
      icon: "🎁",
    },
    {
      id: "TXN006",
      type: "debit",
      description: "Parking - Green Park",
      amount: 67.5,
      date: "2024-01-08",
      time: "08:00",
      icon: "🅿️",
    },
  ];

  const filteredTransactions = transactions.filter((t) => {
    if (filterType === "credit") return t.type === "credit";
    if (filterType === "debit") return t.type === "debit";
    return true;
  });

  const handleAddFunds = () => {
    if (fundAmount) {
      alert(`₹${fundAmount} added to your wallet!`);
      setIsAddingFunds(false);
      setFundAmount("");
    }
  };

  const handleRedeemPoints = () => {
    navigate("/eco-wallet");
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-card border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-2 text-primary font-semibold hover:gap-3 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
            Back
          </button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-lg font-bold text-white">P</span>
            </div>
            <h1 className="text-2xl font-bold text-foreground hidden sm:block">
              ParkEase
            </h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Balance Cards */}
        <div className="mb-12 grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* ParkEase Wallet */}
          <div className="p-8 rounded-2xl bg-gradient-to-br from-blue-600 to-blue-700 text-white relative overflow-hidden">
            <div className="absolute top-0 right-0 w-40 h-40 bg-white/10 rounded-full -mr-20 -mt-20"></div>
            <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/10 rounded-full -ml-16 -mb-16"></div>

            <div className="relative z-10">
              <div className="flex items-center justify-between mb-12">
                <h3 className="text-xl font-bold">ParkEase Wallet</h3>
                <CreditCard className="w-8 h-8" />
              </div>

              <div className="mb-8">
                <p className="text-white/80 text-sm mb-2">Current Balance</p>
                <p className="text-5xl font-bold">₹{walletBalance}</p>
              </div>

              <div className="flex items-end justify-between">
                <div>
                  <p className="text-white/80 text-xs mb-1">Card Number</p>
                  <p className="font-mono text-lg font-semibold">
                    •••• •••• •••• 2450
                  </p>
                </div>
                <p className="text-white/80 text-xs">Valid Thru</p>
              </div>
            </div>
          </div>

          {/* Eco Points */}
          <div className="p-8 rounded-2xl bg-gradient-to-br from-green-600 to-green-700 text-white relative overflow-hidden">
            <div className="absolute top-0 right-0 w-40 h-40 bg-white/10 rounded-full -mr-20 -mt-20"></div>
            <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/10 rounded-full -ml-16 -mb-16"></div>

            <div className="relative z-10">
              <div className="flex items-center justify-between mb-12">
                <h3 className="text-xl font-bold">Eco Points</h3>
                <span className="text-3xl">🌱</span>
              </div>

              <div className="mb-8">
                <p className="text-white/80 text-sm mb-2">Available Points</p>
                <p className="text-5xl font-bold">{totalEcoPoints}</p>
              </div>

              <div className="flex items-end justify-between">
                <p className="text-white/80 text-xs">
                  Redeem rewards or donate to environment
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mb-12 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <button
            onClick={() => setIsAddingFunds(true)}
            className="p-6 rounded-xl border-2 border-border bg-card hover:border-primary hover:shadow-lg transition-all flex flex-col items-center justify-center gap-3 text-center"
          >
            <Plus className="w-8 h-8 text-primary" />
            <span className="font-semibold text-foreground">Add Funds</span>
          </button>

          <button
            className="p-6 rounded-xl border-2 border-border bg-card hover:border-primary hover:shadow-lg transition-all flex flex-col items-center justify-center gap-3 text-center"
          >
            <Send className="w-8 h-8 text-primary" />
            <span className="font-semibold text-foreground">Send Money</span>
          </button>

          <button
            onClick={handleRedeemPoints}
            className="p-6 rounded-xl border-2 border-border bg-card hover:border-secondary hover:shadow-lg transition-all flex flex-col items-center justify-center gap-3 text-center"
          >
            <Zap className="w-8 h-8 text-secondary" />
            <span className="font-semibold text-foreground">Redeem Points</span>
          </button>

          <button
            className="p-6 rounded-xl border-2 border-border bg-card hover:border-primary hover:shadow-lg transition-all flex flex-col items-center justify-center gap-3 text-center"
          >
            <Download className="w-8 h-8 text-primary" />
            <span className="font-semibold text-foreground">Download Statement</span>
          </button>
        </div>

        {/* Add Funds Modal */}
        {isAddingFunds && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <div className="bg-card rounded-2xl border-2 border-border max-w-md w-full p-8">
              <h2 className="text-2xl font-bold text-foreground mb-6">
                Add Funds to Wallet
              </h2>

              <div className="space-y-6 mb-8">
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-3">
                    Enter Amount (₹)
                  </label>
                  <input
                    type="number"
                    value={fundAmount}
                    onChange={(e) => setFundAmount(e.target.value)}
                    placeholder="500"
                    min="100"
                    max="50000"
                    className="w-full px-4 py-3 rounded-lg border-2 border-border bg-background focus:border-primary focus:outline-none transition-colors"
                  />
                </div>

                {/* Quick Amount Options */}
                <div>
                  <p className="text-sm font-semibold text-foreground mb-3">
                    Quick Add
                  </p>
                  <div className="grid grid-cols-4 gap-2">
                    {[500, 1000, 2000, 5000].map((amount) => (
                      <button
                        key={amount}
                        onClick={() => setFundAmount(amount.toString())}
                        className={`py-2 rounded-lg border-2 font-semibold transition-all ${
                          fundAmount === amount.toString()
                            ? "border-primary bg-blue-50 text-primary"
                            : "border-border bg-background text-foreground hover:border-primary"
                        }`}
                      >
                        ₹{amount / 1000}k
                      </button>
                    ))}
                  </div>
                </div>

                {/* Payment Methods */}
                <div>
                  <p className="text-sm font-semibold text-foreground mb-3">
                    Pay Via
                  </p>
                  <div className="space-y-2">
                    {["UPI", "Credit/Debit Card", "Netbanking"].map((method) => (
                      <label
                        key={method}
                        className="flex items-center gap-3 p-3 rounded-lg border-2 border-border hover:border-primary cursor-pointer transition-colors"
                      >
                        <input
                          type="radio"
                          name="payment"
                          defaultChecked={method === "UPI"}
                          className="accent-primary"
                        />
                        <span className="font-semibold text-foreground">
                          {method}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => setIsAddingFunds(false)}
                  className="flex-1 py-3 px-4 rounded-lg border-2 border-primary text-primary font-semibold hover:bg-blue-50 transition-all"
                >
                  Cancel
                </button>
                <button
                  onClick={handleAddFunds}
                  disabled={!fundAmount}
                  className="flex-1 py-3 px-4 rounded-lg bg-gradient-to-r from-primary to-blue-600 text-white font-semibold hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Add ₹{fundAmount || "0"}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Balance Chart */}
        <div className="mb-12 p-8 rounded-2xl bg-card border-2 border-border">
          <h3 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2">
            <TrendingUp className="w-6 h-6 text-primary" />
            Balance History
          </h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={balanceHistory}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="month" stroke="var(--muted-foreground)" />
              <YAxis stroke="var(--muted-foreground)" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "var(--card)",
                  border: "2px solid var(--border)",
                  borderRadius: "8px",
                }}
              />
              <Line
                type="monotone"
                dataKey="balance"
                stroke="hsl(217 72% 51%)"
                strokeWidth={3}
                dot={{ fill: "hsl(217 72% 51%)", r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Transaction History */}
        <div>
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-bold text-foreground">
              Transaction History
            </h2>
            <div className="flex gap-2 bg-card rounded-lg border-2 border-border p-1">
              <button
                onClick={() => setFilterType("all")}
                className={`px-4 py-2 rounded font-semibold transition-all ${
                  filterType === "all"
                    ? "bg-primary text-white"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                All
              </button>
              <button
                onClick={() => setFilterType("credit")}
                className={`px-4 py-2 rounded font-semibold transition-all ${
                  filterType === "credit"
                    ? "bg-secondary text-white"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                Credit
              </button>
              <button
                onClick={() => setFilterType("debit")}
                className={`px-4 py-2 rounded font-semibold transition-all ${
                  filterType === "debit"
                    ? "bg-destructive text-white"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                Debit
              </button>
            </div>
          </div>

          <div className="rounded-2xl border-2 border-border bg-card overflow-hidden">
            <div className="divide-y divide-border">
              {filteredTransactions.map((transaction) => (
                <div
                  key={transaction.id}
                  className="p-6 hover:bg-muted transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4 flex-1">
                      <div
                        className={`w-12 h-12 rounded-lg flex items-center justify-center text-xl ${
                          transaction.type === "credit"
                            ? "bg-green-100"
                            : "bg-blue-100"
                        }`}
                      >
                        {transaction.icon}
                      </div>

                      <div className="flex-1">
                        <h4 className="font-bold text-foreground">
                          {transaction.description}
                        </h4>
                        <p className="text-sm text-muted-foreground">
                          {transaction.date} at {transaction.time}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p
                          className={`text-lg font-bold ${
                            transaction.type === "credit"
                              ? "text-secondary"
                              : "text-primary"
                          }`}
                        >
                          {transaction.type === "credit" ? "+" : "-"}₹
                          {transaction.amount}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Transaction ID: {transaction.id}
                        </p>
                      </div>

                      {transaction.type === "credit" ? (
                        <ArrowDownLeft className="w-5 h-5 text-secondary" />
                      ) : (
                        <ArrowUpRight className="w-5 h-5 text-primary" />
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
