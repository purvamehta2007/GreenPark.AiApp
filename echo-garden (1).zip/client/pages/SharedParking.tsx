import { useNavigate } from "react-router-dom";
import { useState } from "react";
import {
  ArrowLeft,
  Home,
  Plus,
  MapPin,
  Clock,
  DollarSign,
  Star,
  Users,
  ChevronRight,
  Navigation,
} from "lucide-react";

export default function SharedParking() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<"browse" | "add">("browse");

  const communitySpaces = [
    {
      id: "CS001",
      owner: "Priya Kumar",
      location: "Connaught Place, Delhi",
      type: "Residential",
      distance: "2.3 km away",
      price: 40,
      availability: "Mon-Fri 9AM-6PM",
      rating: 4.8,
      reviews: 28,
      image: "🏠",
    },
    {
      id: "CS002",
      owner: "Arjun Singh",
      location: "Sector 62, Noida",
      type: "Office Building",
      distance: "1.8 km away",
      price: 60,
      availability: "All week 6AM-10PM",
      rating: 4.5,
      reviews: 15,
      image: "🏢",
    },
    {
      id: "CS003",
      owner: "Neha Sharma",
      location: "Dwarka, Delhi",
      type: "Residential Complex",
      distance: "5.2 km away",
      price: 30,
      availability: "Weekends only",
      rating: 4.9,
      reviews: 42,
      image: "🏘️",
    },
    {
      id: "CS004",
      owner: "Rohit Patel",
      location: "Gurugram Business Park",
      type: "Commercial",
      distance: "3.1 km away",
      price: 75,
      availability: "Daily 24/7",
      rating: 4.7,
      reviews: 33,
      image: "🏗️",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-card border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-2 text-primary font-semibold hover:gap-3 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
            Back
          </button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-lg font-bold text-white">P</span>
            </div>
            <h1 className="text-2xl font-bold text-foreground hidden sm:block">
              ParkEase
            </h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Hero */}
        <div className="mb-12 text-center">
          <h1 className="text-4xl font-bold text-foreground mb-4 flex items-center justify-center gap-3">
            <Home className="w-10 h-10 text-primary" />
            Shared Parking Exchange
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Share your private parking space and earn extra income. Browse available community-listed spaces.
          </p>
        </div>

        {/* Tabs */}
        <div className="mb-12 flex gap-4 border-b-2 border-border">
          <button
            onClick={() => setActiveTab("browse")}
            className={`px-6 py-4 font-bold transition-all ${
              activeTab === "browse"
                ? "border-b-2 border-primary text-primary -mb-0.5"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Browse Spaces
          </button>
          <button
            onClick={() => setActiveTab("add")}
            className={`px-6 py-4 font-bold transition-all ${
              activeTab === "add"
                ? "border-b-2 border-primary text-primary -mb-0.5"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            List My Space
          </button>
        </div>

        {/* Browse Tab */}
        {activeTab === "browse" && (
          <div>
            <h2 className="text-2xl font-bold text-foreground mb-8">
              Available Community Spaces
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
              {communitySpaces.map((space) => (
                <button
                  key={space.id}
                  className="p-6 rounded-2xl bg-card border-2 border-border hover:border-primary hover:shadow-lg transition-all text-left group"
                >
                  <div className="flex items-start gap-4 mb-4">
                    <div className="text-5xl">{space.image}</div>
                    <div className="flex-1">
                      <h3 className="font-bold text-foreground text-lg mb-1">
                        {space.owner}'s Space
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {space.type}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-3 mb-6">
                    <div className="flex items-center gap-2 text-sm">
                      <MapPin className="w-4 h-4 text-muted-foreground" />
                      <span className="text-muted-foreground">{space.location}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Navigation className="w-4 h-4 text-muted-foreground" />
                      <span className="font-semibold text-foreground">
                        {space.distance}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Clock className="w-4 h-4 text-muted-foreground" />
                      <span className="text-muted-foreground">
                        {space.availability}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between mb-6 pb-6 border-b border-border">
                    <div>
                      <p className="text-muted-foreground text-xs mb-1">Price</p>
                      <p className="text-2xl font-bold text-primary">
                        ₹{space.price}/hr
                      </p>
                    </div>
                    <div className="flex items-center gap-1">
                      <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                      <span className="font-bold text-foreground">
                        {space.rating}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        ({space.reviews})
                      </span>
                    </div>
                  </div>

                  <button className="w-full py-2 px-4 rounded-lg bg-primary text-white font-semibold hover:shadow-lg transition-all flex items-center justify-center gap-2 group-hover:scale-105">
                    Book Space
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </button>
              ))}
            </div>

            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="p-6 rounded-xl text-center bg-card border-2 border-border">
                <Users className="w-8 h-8 text-primary mx-auto mb-3" />
                <p className="text-3xl font-bold text-foreground mb-1">1,234</p>
                <p className="text-muted-foreground">Active Hosts</p>
              </div>

              <div className="p-6 rounded-xl text-center bg-card border-2 border-border">
                <Home className="w-8 h-8 text-secondary mx-auto mb-3" />
                <p className="text-3xl font-bold text-foreground mb-1">5,678</p>
                <p className="text-muted-foreground">Listed Spaces</p>
              </div>

              <div className="p-6 rounded-xl text-center bg-card border-2 border-border">
                <DollarSign className="w-8 h-8 text-primary mx-auto mb-3" />
                <p className="text-3xl font-bold text-foreground mb-1">₹2.5M</p>
                <p className="text-muted-foreground">Earned by Hosts</p>
              </div>
            </div>
          </div>
        )}

        {/* Add Tab */}
        {activeTab === "add" && (
          <div>
            <div className="max-w-2xl mx-auto">
              <h2 className="text-2xl font-bold text-foreground mb-8">
                List Your Parking Space
              </h2>

              <form className="space-y-6 p-8 rounded-2xl bg-card border-2 border-border">
                {/* Space Name */}
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-3">
                    Space Name
                  </label>
                  <input
                    type="text"
                    placeholder="e.g., Home Garage, Office Parking"
                    className="w-full px-4 py-3 rounded-lg border-2 border-border bg-background focus:border-primary focus:outline-none transition-colors"
                  />
                </div>

                {/* Location */}
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-3">
                    Location Address
                  </label>
                  <input
                    type="text"
                    placeholder="Full address with street name"
                    className="w-full px-4 py-3 rounded-lg border-2 border-border bg-background focus:border-primary focus:outline-none transition-colors"
                  />
                </div>

                {/* Space Type */}
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-3">
                    Space Type
                  </label>
                  <select className="w-full px-4 py-3 rounded-lg border-2 border-border bg-background focus:border-primary focus:outline-none transition-colors">
                    <option>Select type...</option>
                    <option>Residential</option>
                    <option>Office Building</option>
                    <option>Commercial</option>
                    <option>Other</option>
                  </select>
                </div>

                {/* Availability */}
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-3">
                    Availability
                  </label>
                  <input
                    type="text"
                    placeholder="e.g., Mon-Fri 9AM-6PM, Weekends only"
                    className="w-full px-4 py-3 rounded-lg border-2 border-border bg-background focus:border-primary focus:outline-none transition-colors"
                  />
                </div>

                {/* Hourly Rate */}
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-3">
                    Hourly Rate (₹)
                  </label>
                  <input
                    type="number"
                    placeholder="40"
                    min="10"
                    max="500"
                    className="w-full px-4 py-3 rounded-lg border-2 border-border bg-background focus:border-primary focus:outline-none transition-colors"
                  />
                </div>

                {/* Features */}
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-3">
                    Features
                  </label>
                  <div className="space-y-2">
                    {["Covered", "Gated", "Well-lit", "Security Camera"].map(
                      (feature) => (
                        <label key={feature} className="flex items-center gap-3">
                          <input
                            type="checkbox"
                            className="w-4 h-4 rounded border-border accent-primary"
                          />
                          <span className="text-foreground">{feature}</span>
                        </label>
                      )
                    )}
                  </div>
                </div>

                {/* Description */}
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-3">
                    Description (Optional)
                  </label>
                  <textarea
                    placeholder="Tell potential renters about your space..."
                    rows={4}
                    className="w-full px-4 py-3 rounded-lg border-2 border-border bg-background focus:border-primary focus:outline-none transition-colors"
                  />
                </div>

                {/* CTA */}
                <button
                  type="submit"
                  className="w-full py-3 px-6 rounded-lg bg-gradient-to-r from-primary to-blue-600 text-white font-semibold shadow-lg hover:shadow-xl hover:scale-105 transition-all flex items-center justify-center gap-2"
                >
                  <Plus className="w-5 h-5" />
                  List My Space
                </button>
              </form>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
