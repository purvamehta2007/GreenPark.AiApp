import { useNavigate } from "react-router-dom";
import {
  User,
  CreditCard,
  Bell,
  Lock,
  LogOut,
  ChevronRight,
  Moon,
  Globe,
} from "lucide-react";
import { useState } from "react";

export default function Profile() {
  const navigate = useNavigate();
  const [darkMode, setDarkMode] = useState(false);

  const handleLogout = () => {
    localStorage.removeItem("isAuthenticated");
    navigate("/login");
  };

  const menuItems = [
    {
      icon: <User className="w-5 h-5" />,
      label: "Account Settings",
      description: "Manage your profile and personal information",
    },
    {
      icon: <CreditCard className="w-5 h-5" />,
      label: "Payment Methods",
      description: "Add or update your payment methods",
    },
    {
      icon: <Bell className="w-5 h-5" />,
      label: "Notifications",
      description: "Control your notification preferences",
    },
    {
      icon: <Lock className="w-5 h-5" />,
      label: "Privacy & Security",
      description: "Manage your security settings",
    },
    {
      icon: <Globe className="w-5 h-5" />,
      label: "Preferences",
      description: "Language, location, and other preferences",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-card border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <button
            onClick={() => navigate("/")}
            className="text-primary font-semibold hover:underline"
          >
            ← Back
          </button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-lg font-bold text-white">P</span>
            </div>
            <h1 className="text-2xl font-bold text-foreground hidden sm:block">
              ParkEase
            </h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Profile Header */}
        <div className="mb-12">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6 p-8 rounded-2xl bg-card border-2 border-border">
            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-secondary to-green-600 text-white font-bold text-3xl flex items-center justify-center">
              JD
            </div>
            <div className="flex-1">
              <h2 className="text-3xl font-bold text-foreground mb-2">
                John Doe
              </h2>
              <p className="text-muted-foreground mb-4">john@example.com</p>
              <div className="flex flex-wrap gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Member Since</p>
                  <p className="font-semibold text-foreground">March 2024</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total Trips</p>
                  <p className="font-semibold text-foreground">24</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Eco Points</p>
                  <p className="font-semibold text-secondary">850</p>
                </div>
              </div>
            </div>
            <button className="px-6 py-2 rounded-lg border-2 border-primary text-primary font-semibold hover:bg-blue-50 transition-all">
              Edit Profile
            </button>
          </div>
        </div>

        {/* Settings Menu */}
        <div className="mb-12">
          <h3 className="text-xl font-bold text-foreground mb-6">Settings</h3>
          <div className="space-y-3">
            {menuItems.map((item, index) => (
              <button
                key={index}
                className="w-full p-4 rounded-lg border-2 border-border bg-card hover:border-primary hover:shadow-lg transition-all flex items-start gap-4 text-left group"
              >
                <div className="w-10 h-10 rounded-lg bg-blue-100 text-primary flex items-center justify-center group-hover:bg-blue-200 transition-colors flex-shrink-0 mt-1">
                  {item.icon}
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-foreground">{item.label}</h4>
                  <p className="text-sm text-muted-foreground">
                    {item.description}
                  </p>
                </div>
                <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors flex-shrink-0 mt-1" />
              </button>
            ))}
          </div>
        </div>

        {/* Preferences */}
        <div className="mb-12">
          <h3 className="text-xl font-bold text-foreground mb-6">Preferences</h3>
          <div className="space-y-4 p-6 rounded-2xl bg-card border-2 border-border">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Moon className="w-5 h-5 text-muted-foreground" />
                <div>
                  <p className="font-semibold text-foreground">Dark Mode</p>
                  <p className="text-sm text-muted-foreground">
                    Coming soon
                  </p>
                </div>
              </div>
              <button
                onClick={() => setDarkMode(!darkMode)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  darkMode ? "bg-secondary" : "bg-muted"
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    darkMode ? "translate-x-6" : "translate-x-1"
                  }`}
                />
              </button>
            </div>

            <div className="border-t border-border pt-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Bell className="w-5 h-5 text-muted-foreground" />
                  <div>
                    <p className="font-semibold text-foreground">
                      Push Notifications
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Get real-time alerts
                    </p>
                  </div>
                </div>
                <button className="relative inline-flex h-6 w-11 items-center rounded-full bg-secondary transition-colors">
                  <span className="inline-block h-4 w-4 transform rounded-full bg-white transition-transform translate-x-6" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Danger Zone */}
        <div className="mb-12">
          <h3 className="text-xl font-bold text-foreground mb-6">Account</h3>
          <div className="space-y-3">
            <button
              onClick={handleLogout}
              className="w-full p-4 rounded-lg border-2 border-destructive bg-red-50 hover:bg-red-100 transition-all flex items-center gap-3 text-left group"
            >
              <div className="w-10 h-10 rounded-lg bg-destructive/10 text-destructive flex items-center justify-center flex-shrink-0">
                <LogOut className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <h4 className="font-semibold text-destructive">Sign Out</h4>
                <p className="text-sm text-destructive/70">
                  Sign out from your account
                </p>
              </div>
              <ChevronRight className="w-5 h-5 text-destructive flex-shrink-0" />
            </button>

            <button className="w-full p-4 rounded-lg border-2 border-destructive bg-red-50 hover:bg-red-100 transition-all flex items-center gap-3 text-left group">
              <div className="w-10 h-10 rounded-lg bg-destructive/10 text-destructive flex items-center justify-center flex-shrink-0">
                <span className="text-lg">⚠️</span>
              </div>
              <div className="flex-1">
                <h4 className="font-semibold text-destructive">Delete Account</h4>
                <p className="text-sm text-destructive/70">
                  Permanently delete your account
                </p>
              </div>
              <ChevronRight className="w-5 h-5 text-destructive flex-shrink-0" />
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}
