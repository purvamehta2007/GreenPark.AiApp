import { useNavigate } from "react-router-dom";
import { useState } from "react";
import {
  ArrowLeft,
  MapPin,
  Clock,
  Calendar,
  TrendingUp,
  Zap,
  AlertCircle,
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
} from "recharts";

export default function Prediction() {
  const navigate = useNavigate();
  const [destination, setDestination] = useState("");
  const [arrivalTime, setArrivalTime] = useState("");
  const [duration, setDuration] = useState("");
  const [hasSearched, setHasSearched] = useState(false);

  const mockForecastData = [
    { time: "10:00", availability: 45, demand: 55 },
    { time: "10:15", availability: 42, demand: 58 },
    { time: "10:30", availability: 38, demand: 62 },
    { time: "10:45", availability: 35, demand: 65 },
    { time: "11:00", availability: 32, demand: 68 },
    { time: "11:15", availability: 28, demand: 72 },
    { time: "11:30", availability: 25, demand: 75 },
  ];

  const mockHourlyData = [
    { hour: "09:00", slots: 120 },
    { hour: "10:00", slots: 98 },
    { hour: "11:00", slots: 76 },
    { hour: "12:00", slots: 54 },
    { hour: "13:00", slots: 42 },
    { hour: "14:00", slots: 38 },
    { hour: "15:00", slots: 45 },
    { hour: "16:00", slots: 67 },
    { hour: "17:00", slots: 89 },
  ];

  const recommendedSlots = [
    {
      id: "SL001",
      name: "Downtown Plaza - Level 2",
      distance: "450m",
      price: 50,
      availability: 12,
      confidence: 92,
      rating: 4.5,
      evCharging: true,
    },
    {
      id: "SL002",
      name: "Tech Hub Garage - Level 1",
      distance: "850m",
      price: 40,
      availability: 8,
      confidence: 87,
      rating: 4.2,
      evCharging: true,
    },
    {
      id: "SL004",
      name: "Mall of India - Ground Floor",
      distance: "650m",
      price: 80,
      availability: 5,
      confidence: 78,
      rating: 4.4,
      evCharging: false,
    },
  ];

  const handlePredictAvailability = (e: React.FormEvent) => {
    e.preventDefault();
    if (destination && arrivalTime && duration) {
      setHasSearched(true);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-card border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-2 text-primary font-semibold hover:gap-3 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
            Back
          </button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-lg font-bold text-white">P</span>
            </div>
            <h1 className="text-2xl font-bold text-foreground hidden sm:block">
              ParkEase
            </h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Search Form */}
        <div className="mb-12">
          <div className="bg-card border-2 border-border rounded-2xl p-8">
            <h2 className="text-2xl font-bold text-foreground mb-6">
              Predict Parking Availability
            </h2>

            <form onSubmit={handlePredictAvailability} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Destination */}
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-3">
                    Destination Location
                  </label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-3.5 w-5 h-5 text-muted-foreground" />
                    <input
                      type="text"
                      value={destination}
                      onChange={(e) => setDestination(e.target.value)}
                      placeholder="Enter location or address"
                      className="w-full pl-10 pr-4 py-3 rounded-lg border-2 border-border bg-background focus:border-primary focus:outline-none transition-colors"
                      required
                    />
                  </div>
                </div>

                {/* Arrival Time */}
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-3">
                    Arrival Time
                  </label>
                  <div className="relative">
                    <Clock className="absolute left-3 top-3.5 w-5 h-5 text-muted-foreground" />
                    <input
                      type="time"
                      value={arrivalTime}
                      onChange={(e) => setArrivalTime(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 rounded-lg border-2 border-border bg-background focus:border-primary focus:outline-none transition-colors"
                      required
                    />
                  </div>
                </div>

                {/* Duration */}
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-3">
                    Duration (hours)
                  </label>
                  <div className="relative">
                    <Zap className="absolute left-3 top-3.5 w-5 h-5 text-muted-foreground" />
                    <input
                      type="number"
                      value={duration}
                      onChange={(e) => setDuration(e.target.value)}
                      placeholder="2"
                      min="0.5"
                      max="24"
                      step="0.5"
                      className="w-full pl-10 pr-4 py-3 rounded-lg border-2 border-border bg-background focus:border-primary focus:outline-none transition-colors"
                      required
                    />
                  </div>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 px-6 rounded-lg bg-gradient-to-r from-primary to-blue-600 text-white font-semibold shadow-lg hover:shadow-xl hover:scale-105 transition-all flex items-center justify-center gap-2"
              >
                <TrendingUp className="w-5 h-5" />
                Predict Availability
              </button>
            </form>
          </div>
        </div>

        {/* Results Section */}
        {hasSearched && (
          <>
            {/* AI Prediction Summary */}
            <div className="mb-12 grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="p-6 rounded-2xl bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-primary">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-foreground">
                    AI Confidence Score
                  </h3>
                  <span className="text-3xl font-bold text-primary">92%</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Based on historical data and real-time trends
                </p>
              </div>

              <div className="p-6 rounded-2xl bg-gradient-to-br from-green-50 to-green-100 border-2 border-secondary">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-foreground">
                    Available Slots
                  </h3>
                  <span className="text-3xl font-bold text-secondary">24</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  At your arrival time in this area
                </p>
              </div>

              <div className="p-6 rounded-2xl bg-gradient-to-br from-yellow-50 to-yellow-100 border-2 border-yellow-600">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-foreground">
                    Avg. Wait Time
                  </h3>
                  <span className="text-3xl font-bold text-yellow-700">
                    2 min
                  </span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Expected time to find a spot
                </p>
              </div>
            </div>

            {/* Charts Section */}
            <div className="mb-12 space-y-8">
              {/* Demand vs Availability */}
              <div className="p-8 rounded-2xl bg-card border-2 border-border">
                <h3 className="text-xl font-bold text-foreground mb-6">
                  Predicted Demand vs Availability
                </h3>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={mockForecastData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis dataKey="time" stroke="var(--muted-foreground)" />
                    <YAxis stroke="var(--muted-foreground)" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "var(--card)",
                        border: "2px solid var(--border)",
                        borderRadius: "8px",
                      }}
                    />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="availability"
                      stroke="hsl(217 72% 51%)"
                      strokeWidth={2}
                      dot={{ fill: "hsl(217 72% 51%)", r: 4 }}
                    />
                    <Line
                      type="monotone"
                      dataKey="demand"
                      stroke="hsl(0 74% 51%)"
                      strokeWidth={2}
                      dot={{ fill: "hsl(0 74% 51%)", r: 4 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              {/* Hourly Availability Chart */}
              <div className="p-8 rounded-2xl bg-card border-2 border-border">
                <h3 className="text-xl font-bold text-foreground mb-6">
                  Next 30 Minutes - Availability Heatmap
                </h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={mockHourlyData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis dataKey="hour" stroke="var(--muted-foreground)" />
                    <YAxis stroke="var(--muted-foreground)" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "var(--card)",
                        border: "2px solid var(--border)",
                        borderRadius: "8px",
                      }}
                    />
                    <Bar
                      dataKey="slots"
                      fill="hsl(112 40% 64%)"
                      radius={[8, 8, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* AI Insights */}
            <div className="mb-12 p-6 rounded-2xl bg-blue-50 border-2 border-blue-200 flex gap-4">
              <AlertCircle className="w-6 h-6 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-semibold text-foreground mb-2">
                  AI Recommendation
                </h4>
                <p className="text-muted-foreground">
                  Based on current traffic patterns, we recommend arriving by
                  10:15 AM for guaranteed availability. Demand is expected to
                  peak around 11:30 AM.
                </p>
              </div>
            </div>

            {/* Recommended Slots */}
            <div className="mb-12">
              <h3 className="text-2xl font-bold text-foreground mb-6">
                Recommended Parking Spots
              </h3>
              <div className="space-y-4">
                {recommendedSlots.map((slot) => (
                  <button
                    key={slot.id}
                    onClick={() => navigate("/reservation")}
                    className="w-full p-6 rounded-2xl bg-card border-2 border-border hover:border-primary hover:shadow-lg transition-all text-left group"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-start gap-4 mb-3">
                          <div className="flex-1">
                            <h4 className="font-bold text-foreground text-lg mb-2">
                              {slot.name}
                            </h4>
                            <div className="flex flex-wrap gap-3 text-sm">
                              <span className="flex items-center gap-1 text-muted-foreground">
                                <MapPin className="w-4 h-4" />
                                {slot.distance}
                              </span>
                              <span className="flex items-center gap-1 text-muted-foreground">
                                <span>₹{slot.price}/hr</span>
                              </span>
                              <span className="flex items-center gap-1 text-secondary font-semibold">
                                ⭐ {slot.rating}
                              </span>
                            </div>
                          </div>

                          {/* Confidence Badge */}
                          <div className="flex flex-col items-end">
                            <div className="px-3 py-1 rounded-full bg-green-100 text-secondary font-semibold text-sm mb-2">
                              {slot.confidence}% Confidence
                            </div>
                            <span className="text-sm font-semibold text-foreground">
                              {slot.availability} slots
                            </span>
                          </div>
                        </div>

                        {/* Features */}
                        <div className="flex gap-2">
                          {slot.evCharging && (
                            <span className="px-3 py-1 rounded-full bg-blue-100 text-primary text-xs font-semibold flex items-center gap-1">
                              <Zap className="w-3 h-3" />
                              EV Charging
                            </span>
                          )}
                        </div>
                      </div>

                      {/* CTA */}
                      <div className="flex flex-col gap-2 sm:min-w-fit">
                        <button className="px-6 py-2 rounded-lg bg-primary text-white font-semibold hover:shadow-lg transition-all whitespace-nowrap">
                          Reserve Now
                        </button>
                        <span className="text-xs text-muted-foreground text-center">
                          Click to proceed
                        </span>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </>
        )}

        {/* Empty State */}
        {!hasSearched && (
          <div className="text-center py-16">
            <div className="mb-8 flex justify-center">
              <div className="w-24 h-24 bg-gradient-to-br from-primary/10 to-secondary/10 rounded-2xl flex items-center justify-center">
                <TrendingUp className="w-12 h-12 text-primary" />
              </div>
            </div>
            <h3 className="text-2xl font-bold text-foreground mb-4">
              No predictions yet
            </h3>
            <p className="text-muted-foreground max-w-md mx-auto">
              Fill in your destination, arrival time, and duration to get
              AI-powered parking predictions and availability forecasts.
            </p>
          </div>
        )}
      </main>
    </div>
  );
}
